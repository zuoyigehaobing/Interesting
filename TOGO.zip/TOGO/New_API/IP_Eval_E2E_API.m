function IP_Eval_E2E_API(IP_Eval_E2E_Parameter_API)

% Main file for IP Evaluation Tool (End to End Version)
% Can be used as function (one argument: IP_Eval_E2E_Parameter_API.m file)
% or run as script (user select parameter file when prompted)

% Tasks Performed:

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
%% INITIALIZATION - Parse config file and load evaluation parameters
% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if ~exist('IP_Eval_E2E_Parameter_API', 'var')
    [file_, path_] = uigetfile('', 'Select Multi-dataset parameter.m file', '*.m');
    if ~exist('file_', 'var'), return, end
    IP_Eval_E2E_Parameter_API = fullfile(path_, file_);
end

% Read IP_Eval_parameter.txt configuration file
config = callfunc(IP_Eval_E2E_Parameter_API);

% Loop over each module and do detection on it over all datasets specified
LoadDirs = [];

for module_idx=1:length(config.pipeline)
  
  module = config.pipeline{module_idx};
  
  switch module.type
    
    case 'LOAD'
      save_dir = module.where_to_load;
      
    case 'ROI'
      save_dir = {fullfile(config.common.eval_basefolder, module.name)};
      ROI_Eval(module, save_dir{1}, config.common);
      
    case 'DETECTION'
      save_dir = {fullfile(config.common.eval_basefolder, module.name)};
      DL_Detection_Eval(module, save_dir{1}, config.common, LoadDirs);
      
    case 'CLASSIFICATION'
      save_dir = {fullfile(config.common.eval_basefolder, module.name)};
      DL_Classification_Eval(module, save_dir{1}, config.common, LoadDirs);
    
    case 'TEMPORAL'
      % TBD
      save_dir = {};
    
    otherwise
      error(['Module Type ' module.type ' Not Supported']);
      
  end
  
  LoadDirs = save_dir;

end

debug = 1;

end
