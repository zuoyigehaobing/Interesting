function config = IP_Eval_E2E_Parameter_API()
    
    % Initialize the output struct format
    config = struct;
    % Where you save the evaluation results (top level folder)
    config.common.eval_basefolder = 'C:\Users\Public\IPR\Stuff_Shan\IP_EvaluationTools\API\Results_Pipeline_Direct';
    % Where to find your Python Interpreter
    config.common.python_path = 'C:\Users\ecl22309\AppData\Local\conda\conda\envs\eval\python.exe';
    % Debug: Tracking running time of each module in the eval frame
    config.common.IProfile = 1;
    
    %% ================  MODULE DEFINITION AND CONFIGURATION  ==================
    
    % [Loading Module]
    module_load = struct;
    module_load.type = 'LOAD';
    module_load.where_to_load = {'C:\Users\Public\IPR\Stuff_Shan\IP_EvaluationTools\API\Results\ROI1420+DL1.7'};
    
    
    % [ROI Module]
    module_roi = struct;
    module_roi.type         = 'ROI'; % Must be one of 'ROI', 'DETECTION', 'CLASSIFICATION', 'TEMPORAL', 'LOAD'
    module_roi.name         = 'ROI1420';
    module_roi.module_path  = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\DetectionModules\ROI\fingertip_localization_ROI_rev_1420\fingertip_detection.m';
    module_roi.api_type     = 'BkgBlk';  %'Bkg', 'BkgBlk', 'FeedGT'
    
    
    % [Detection Module]
    module_detection = struct;
    module_detection.type         = 'DETECTION'; % Must be one of 'ROI', 'DETECTION', 'CLASSIFICATION', 'TEMPORAL', 'LOAD'
    module_detection.name         = 'ROI1420+DL1.7';
    module_detection.module_path  = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\DetectionModules\4x4x3DL\oldModules\detection_D1.7_L_MATLAB.hdf5';
    module_detection.api_type     = '4x4x3';     % '1x1x3', '4x4x3';
    
    
    % [Classification Module]
    module_classif              = struct;
    module_classif.type         = 'CLASSIFICATION'; % Must be one of 'ROI', 'DETECTION', 'CLASSIFICATION', 'TEMPORAL', 'LOAD'
    module_classif.name         = 'DLTH1.7';
    module_classif.module_path  = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\DetectionModules\DLClassificationModels\Seq_Required\DLTH1.7.hdf5';
    module_classif.probThresh   = 0.5;
    
    % [Temporal Module]
    %%%%% TBD
    
    
    %%  ====================  EVALUATION PIPELINE  ========================

    % Option(1) Evaluate from very beginning
    % config.pipeline = {module_roi, module_detection, module_classif};
    
    % Option(2) Load from previous module and update the results after that
    config.pipeline = {module_load, module_classif};
    
    
    
    %% ===================== EVALUATION DATASETS ===========================
    
    % Will Explore all sgt file rooted in these directories, recursivelly
    Sequence_Directory = {
    ...'E:\DataServerBkp\fromEdge\20190128_Susan_Sequence_Data\20190125_TopRegion\Susan',
    ...'E:\DataServerBkp\fromEdge\20180921_False_Set',
    'C:\Users\Public\IPR\Stuff_Shan\IP_EvaluationTools\API\DebugDataset',
    };

    % Parameters that ARE specific per dataset
    dataset_names = {... short list of all datasets to evaluate. Comment out datasets that are not to be evaluated
                    ...
                    ...'iteration1_Dong_Data',...
                    };
    
    % Sequence Directory Exploration
    dataset_idx = 1;
    for seq_dir_idx =1:length(Sequence_Directory)
      
      dataset_list = dir(Sequence_Directory{seq_dir_idx});
      
      for item_idx=1:length(dataset_list)
        
        item = dataset_list(item_idx);
        item_path = fullfile(item.folder, item.name);
        
        % Skip '.', '..' and non-directory files
        if strcmp('.', item.name) || strcmp('..', item.name) || (~ isdir(item_path))
          continue;
        end
        
        % Assume the folder contains sgt file and add the folder to eval_list
        config.common.datasets(dataset_idx).dataset_name     = item.name;     
        config.common.datasets(dataset_idx).dataset_path     = item_path;    
        config.common.datasets(dataset_idx).sgt_filename     = 'all.sgt';
        config.common.datasets(dataset_idx).bkgname_c1       = 'sgt';       
        config.common.datasets(dataset_idx).blkname_c1       = 'sgt';       
        config.common.datasets(dataset_idx).filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt'; 
        config.common.datasets(dataset_idx).is_seq_data      = 1;   % Window Crop
        
        % Next dataset
        dataset_idx = dataset_idx + 1;
      end
      
    end
    
    

    % Define Individual dataset-specific parameters
    for i = 1:length(dataset_names)
        
        dataset_name = dataset_names{i};
        
        switch dataset_name
		
 
			case 'iteration1_Dong_Data'
                dataset_path     = 'E:\DataServerBkp\fromEdge\DL_Dataset\iteration1_watt1\rectified_Dong';
                sgt_filename     = 'all - Copy.sgt';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                is_seq_data      = 0;
                
        end
    
        config.common.datasets(dataset_idx).dataset_name     = dataset_name;     
        config.common.datasets(dataset_idx).dataset_path     = dataset_path;    
        config.common.datasets(dataset_idx).sgt_filename     = sgt_filename;
        config.common.datasets(dataset_idx).bkgname_c1       = bkgname_c1;       
        config.common.datasets(dataset_idx).blkname_c1       = blkname_c1;       
        config.common.datasets(dataset_idx).filter_file      = filter_file;
        config.common.datasets(dataset_idx).is_seq_data      = is_seq_data;   % Window Crop
        
        % Next Dataset
        dataset_idx = dataset_idx + 1;
        
    end
    
    
    % ==================== [Reporting Configuration] ==========================
    
    % When GT_Z < MinimumHoverZ, it's considered to be touch, else hover
    config.common.MinimumHoverZ = 10;
    
    % When Err_R <= dR, it's considered to be correct detection in report
    config.common.dR = [10, 15 ,20, 25, 30];

    
end

