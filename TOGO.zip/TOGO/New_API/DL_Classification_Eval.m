function DL_Classification_Eval(module, save_dir, common, LoadDirs)

% DL-Classification Evaluation Module

% INPUTS:
%     (1) module: DL_Classification_Eval module struct
%           .type           - 'CLASSIFICATION'
%           .name           - e.g. 'DLTH1.5'
%           .module_path    - full file path of the main Classification Model
%           .LoadDirs       -  Previous Evaluation outputs which you need
%                              to load from and connect with DL-Classification Evaluation
%     (2) save_dir: top-level folder where you save the results
%     (3) common: common field in configuration file, includes
%           .eval_basefolder  - higher level folder where you save eval results of all modules
%           .python_path      - where to load your Python interpreter
%           .datasets         - evaluation lists
%           .MinimumHoverZ    - (*) Used in Reporting: when GT_Z >= MinimumHoverZ, it's hover
%           .dR               - (*) Used in Reporting: When Err_R <= dR, it's correct in localization
%     (4) LoadDirs: Where you load detection results from previous module


% ACTIONS:
%   (1) For each dataset in the evaluation list, run DL_Classification evaluation on it
%   (2) Support Report Generation

    %% Loop over datasets
    for dataset_idx = 1:length(common.datasets)
        
        % Load SGT and the Filter File
        dataset_path   = common.datasets(dataset_idx).dataset_path;
        dataset_name   = common.datasets(dataset_idx).dataset_name;
        sgt_filepath = fullfile(dataset_path, common.datasets(dataset_idx).sgt_filename);
        GT = readSGT(sgt_filepath, common.datasets(dataset_idx).filter_file);

        % Eval base folder for this dataset
        eval_folder = fullfile(save_dir, common.datasets(dataset_idx).dataset_name);
        mkdir(eval_folder); 
        
        % Clear previous ALL_detModPoses if exists, reset nImgPairs
        clear ALL_detModPoses;
        nImgPairs = 0;
        
        % Load detection Results from previous module
        load_file_path = find_load_path(LoadDirs, dataset_name);
        load(load_file_path, 'ALL_detModPoses');
        
        % For Classification, evaluation results collected in Python via
        % command line
        tic;
        load_file = classification_eval_dataset_based(module, dataset_path, load_file_path, common);
        load(load_file, 'ALL_detModPoses');
        delete(load_file);
        toc;
        
        % Display current dataset
        fprintf('\n[%s] Eval on [%s] (%d/%d)\n', module.name, dataset_name, dataset_idx, length(common.datasets));
        fprintf('Total images: [%d]. Imgs processed:\n', length(GT));
        
        % Loop over images and do detection
        for i = 1:length(GT)
          
          % -- Display Loop progress
          if ismember(i, round(linspace(1,length(GT),30)) ), fprintf('%d..', i); end
          
          % -- READ c1 images (not c2, not bkground / black) 
          if isempty(strfind(GT(i).PictureName, '_c1')) 
              continue; 
          end
          
          % Load GT_C1 and GT_C2
          GT_idx1 = i; GT_c1 = GT(GT_idx1); imgname_c1 = GT_c1.PictureName;
          GT_idx2 = i + 1; GT_c2 = GT(GT_idx2); imgname_c2 = GT_c2.PictureName;
          
          % Make sure that GT_C1 and Matches the current detection of
          % previous Module
          det_idx = (i + 1) / 2; % Since Detection only record on C1
          if ~ strcmp(imgname_c1, ALL_detModPoses(det_idx).PictureName)
              error('Ground Truth and Previous Module Detection not match in images\n');
          end

          % Process GT to get the location for the image pair, convert GT_Z into touch/hover
          GT = process_GT(GT, GT_idx1, 'AVG', common.MinimumHoverZ);
          
          
          
        end
        
        
        % Save detection results (raw; without analysis)
        fprintf('\n');
        writeDetResCSV(eval_folder, ALL_detModPoses, GT);
        
    end

end