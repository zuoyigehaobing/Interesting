function [load_path] = find_load_path(roots, dataset_name)

% The function takes two parameter and return a loading path. For example,
% we need to load ROI result to do classification or regression. This
% function helps to find the loading file path.

% INPUTS:
%   (1) roots : Root folders where you want to find the loading dataset.
%              e.g. 'C:\somepath\ROI1420', inside this folder we probably
%              want to find dataset 'Dataset1'
%   (2) dataset_name: the name of the dataset

% ACTIONS:
%   Go inside root directory, find the folder that contains dataset_name as
%   part of it's name. Then go inside this folder, find the file
%   detectionResults.mat and return the path. Will raise error if we did
%   not find this file path.
    dataset_load_path = '';
    
    for root_idx=1:length(roots)
        
        root = roots{root_idx};
        
        item_list = dir(root);
    
        % Find the directory inside root directory

        for item_idx=1:length(item_list)

            item_path = fullfile(root, item_list(item_idx).name);
            if isdir(item_path) && contains(item_list(item_idx).name, dataset_name)
                dataset_load_path = item_path;
                break;
            end

        end 
        
        if isdir(dataset_load_path)
            break;
        end
        
    end


    % If no such dataset folder, raise error
    if ~isdir(dataset_load_path)
        error('Folder %s not found in directory %s\n', dataset_name, root);
    end
    
    % Find detectionResults.mat recursively in dataset_load_path
    load_path = find_file_recursively(dataset_load_path, 'detectionResults.mat', 0);
    
    % Raise Error if such file not found
    if ~isfile(load_path)
        error('%s not found in directory %s\n', 'detectionResults.mat', dataset_load_path);
    end
    
    
end




function [file_path] = find_file_recursively(root, filename, is_substring)

% search file recursively rooted from root directory, if is_substring == 1
% 'detectionResult.mat' will be returned even if you pass 'detect' as
% filename since 'detect' is substring of 'detectionResult.mat'
    file_path = '';

    items = dir(root);
    
    for i = 3:length(items)
        
        element = items(i).name;
        
        if ~items(i).isdir && contains(element, filename) && is_substring
            file_path = fullfile(root, element);
            return;
        elseif ~items(i).isdir && strcmp(element, filename) && ~is_substring
            file_path = fullfile(root, element);
            return;
        end
        
        if items(i).isdir
            next_level = fullfile(root, element);
            file_path = find_file_recursively(next_level, filename, is_substring);
            if isfile(file_path)
                return;
            end
        end
            
            
    end


end
