classdef KerasModelPredictor

    properties
        KerasModel
    end 
    
    methods
    
        function obj = KerasModelPredictor(modelFile)
            % Initialize
            obj.KerasModel = importKerasNetwork(modelFile, 'OutputLayerType', 'regression');
        end
        
        
        function detModPoses = Predict(obj, img_c1, img_c2, detModInfo, api_type)
            
            % INPUTS:
            %   (1) img_c1, img_c2 are loaded C1 and C2 images
            %   (2) detModInfo: struct
            %           .PictureName            - PictureName of img_c1
            %           .detModPoses            - detection results from
            %                                       previous Models
            %           .t_detect               - detection time
            %           .c1_index               - image index of c1 image
            %   (3) api_type:                   - '4x4x3' or '1x1x3'
            
            % ACTIONS:
            %   (1) Crop ROIs based on detModInfo
            %   (2) Make prediction on Detection Network
            
            % Initialization of the output format
            detModPoses = struct;
            detModPoses.modName = 'DL-Detection'; % Need to be fixed
            detModPoses.PoseX = [];
            detModPoses.PoseY = [];
            detModPoses.PoseZ = [];
            
            % Get the ROI size based on the model itself
            ROI_SIZE = obj.KerasModel.Layers(1).InputSize(1);
            
            
            %% GET NECESSARY INFOS AND LOOP OVER POSES
            for pose_idx=1:length(detModInfo.detModPoses.PoseX)
                
                posex = detModInfo.detModPoses.PoseX(pose_idx);
                posey = detModInfo.detModPoses.PoseY(pose_idx);
                posez = detModInfo.detModPoses.PoseZ(pose_idx);
                
                % get minimum range of valid ---------- NNED TO CONFIRM
                xmin = floor( min( max(posex - ROI_SIZE/2, 1), 1280 - ROI_SIZE + 1 ) );
                ymin = floor( min( max(posey - ROI_SIZE/2, 1), 800 - ROI_SIZE + 1 ) );

                % get the roi region
                roi_c1 = img_c1(ymin:ymin+ROI_SIZE-1, xmin:xmin+ROI_SIZE-1, :);
                roi_c2 = img_c2(ymin:ymin+ROI_SIZE-1, xmin:xmin+ROI_SIZE-1, :);
                
                % Obtain Prediction
                pred_c1 = obj.KerasModel.predict(roi_c1(:,:,1));
                pred_c2 = obj.KerasModel.predict(roi_c2(:,:,1));
                
                % get PoseX and PoseY by applying nms
                [PoseX, PoseY, ~] = obj.yolo_prediction_nms(pred_c1, pred_c2, ROI_SIZE, 25, 0.01, true, api_type);
                PoseX = PoseX(:) + xmin;
                PoseY = PoseY(:) + ymin;
                PoseZ = ones(size(PoseX));          % Need to discuss
                
                % FORMAL USE
                detModPoses.PoseX = [detModPoses.PoseX; PoseX];
                detModPoses.PoseY = [detModPoses.PoseY; PoseY];
                detModPoses.PoseZ = [detModPoses.PoseZ; PoseZ];
                
                
            end
            
        end
        
        
        
    end
    
    
    
    
    methods (Access=private)
        
        function [PoseX, PoseY, PoseZ] = yolo_prediction_nms(obj, pred_c1, pred_c2, ROI_SIZE, DistThres, ConfThres, iWEIGHTED_AVG_PRED, api_type)
            
            % Convert two 4x4x3 prediction tensors to 
            % one 32x3 tensor of (conf, global x, global y)
            vectorIdx = 0;
            
            if strcmp(api_type, '4x4x3')
                GridSqSize = ROI_SIZE / 4;
                for boxRow = 1:4
                    for boxCol = 1:4            

                        % c1 prediction
                        conf  = pred_c1(boxRow,boxCol,1);
                        X = GridSqSize * (boxCol-1 + pred_c1(boxRow,boxCol,2));
                        Y = GridSqSize * (boxRow-1 + pred_c1(boxRow,boxCol,3));

                        vectorIdx = vectorIdx + 1;
                        conf_x_y_vector(vectorIdx, 1) = conf;
                        conf_x_y_vector(vectorIdx, 2) = X;
                        conf_x_y_vector(vectorIdx, 3) = Y;

                        % c2 prediction
                        conf  = pred_c2(boxRow,boxCol,1);
                        X = GridSqSize * (boxCol-1 + pred_c2(boxRow,boxCol,2));
                        Y = GridSqSize * (boxRow-1 + pred_c2(boxRow,boxCol,3));

                        vectorIdx = vectorIdx + 1;
                        conf_x_y_vector(vectorIdx, 1) = conf;
                        conf_x_y_vector(vectorIdx, 2) = X;
                        conf_x_y_vector(vectorIdx, 3) = Y;

                    end
                end
                
            elseif  strcmp(api_type, '1x1x3')
                GridSqSize = ROI_SIZE;
                for boxRow = 1:1
                    for boxCol = 1:1            
                        
                        % c1 prediction
                        conf = pred_c1(1);
                        X = GridSqSize * (boxCol-1 + pred_c1(2));
                        Y = GridSqSize * (boxRow-1 + pred_c1(3));
                        vectorIdx = vectorIdx + 1;
                        conf_x_y_vector(vectorIdx, 1) = conf;
                        conf_x_y_vector(vectorIdx, 2) = X;
                        conf_x_y_vector(vectorIdx, 3) = Y;

                        % c2 prediction
                        conf = pred_c2(1);
                        X = GridSqSize * (boxCol-1 + pred_c2(2));
                        Y = GridSqSize * (boxRow-1 + pred_c2(3));
                        vectorIdx = vectorIdx + 1;
                        conf_x_y_vector(vectorIdx, 1) = conf;
                        conf_x_y_vector(vectorIdx, 2) = X;
                        conf_x_y_vector(vectorIdx, 3) = Y;
                    end
                end
            else
                error('DL-Detection Model %s is not Supported \n', api_type);
            end
            
            

            % Sort conf_x_y_vector by confidence (first column)
            conf_x_y_vector = sortrows(conf_x_y_vector);
            
            % Cluster predictions
            numOfOutputs = 0;
            [PoseX, PoseY] = deal([]);
            while max(conf_x_y_vector(:,1)) > ConfThres
            
                numOfOutputs = numOfOutputs + 1;
                
                % Get X,Y corresponding to the highest confidence detection
                rowIdx = find( conf_x_y_vector(:,1) == max(conf_x_y_vector(:,1)) ); rowIdx = rowIdx(1);
                X = conf_x_y_vector(rowIdx,2);
                Y = conf_x_y_vector(rowIdx,3);

                % Cluster all detections which are within distance threshold of this X,Y
                dists = sqrt( (conf_x_y_vector(:,2)-X).^2 + (conf_x_y_vector(:,3)-Y).^2 );
                rowsToCluster = find(dists < DistThres);

                % Take a weighted average of detections in this cluster, or simply take the maximal value
                if iWEIGHTED_AVG_PRED
                    
                    totalConfWeight = sum( conf_x_y_vector(rowsToCluster, 1) );
                    X_avg = sum( (conf_x_y_vector(rowsToCluster, 2) .* conf_x_y_vector(rowsToCluster, 1)) ) / totalConfWeight;
                    Y_avg = sum( (conf_x_y_vector(rowsToCluster, 3) .* conf_x_y_vector(rowsToCluster, 1)) ) / totalConfWeight;
                    
                    PoseX(numOfOutputs) = X_avg; 
                    PoseY(numOfOutputs) = Y_avg; 
                    
                else
                    PoseX(numOfOutputs) = X; 
                    PoseY(numOfOutputs) = Y; 
                
                end
                
                % Set confidence of detections in this cluster to 0, to mark them as clustered
                conf_x_y_vector(rowsToCluster, 1) = 0;

            end

            PoseZ = ones(size(PoseX));
            
        end
        
            
        function img = min_max_normalization(img, saturation)   
        
            if ~exist('saturation', 'var'), saturation=0; end
            
            min_val = percentile(img, saturation);
            max_val = percentile(img, 100-saturation);
            
            img = (img - min_val) ./ (max_val - min_val + 0.00001);
            img = min(img, 1);
            
            img = im2uint8(255*img);
            
        end
        
    end


end

