import scipy.io
import sys
import argparse
import numpy as np
import keras
import cv2
import os
from datetime import datetime
from copy import deepcopy

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


def crop_to_roi(img, center, roi_size):
    """
    This functions crops an ROI out from an image. If ROI goes out of image boarder,
    ROI center will be shifted to ensure that ROI is within input image, with image border and ROI boarder aligned.
    :param img: input image
    :param center: ROI center location in input image
    :param roi_size: dimension of square-shaped ROI
    :return: ROI
    """
    raw_y, raw_x = img.shape
    rad = int(roi_size / 2)
    x, y = center
    x = max(rad, min([x, raw_x - rad]))
    y = max(rad, min([y, raw_y - rad]))
    return img[y - rad:y + rad, x - rad:x + rad]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('modelFile', type=str)
    parser.add_argument('matlab_variable', type=str)
    parser.add_argument('dataset_path', type=str)
    parser.add_argument('probThreshold', type=float)
    args = parser.parse_args()

    # Load classification Model
    model = keras.models.load_model(args.modelFile, compile=False)

    # Load ROIs
    variable = deepcopy(scipy.io.loadmat(args.matlab_variable))
    ALL_detModPoses = variable['ALL_detModPoses'][0]

    left_image_batch = np.zeros((1, 128, 128, 1))
    right_image_batch = np.zeros((1, 128, 128, 1))

    # Loop over images
    rval = ''
    for i in range(len(ALL_detModPoses)):

        cur_img_info = ALL_detModPoses[i]

        img_name = cur_img_info[0][0]

        img_path = os.path.join(args.dataset_path, img_name)

        pose_x = cur_img_info[1][0][0][1]
        pose_y = cur_img_info[1][0][0][2]
        pose_z = cur_img_info[1][0][0][3]

        if len(pose_x) == 0:
            continue

        for pose_id in range(len(pose_x)):
            cur_x, cur_y = int(pose_x[pose_id][0] - 1), int(pose_y[pose_id][0] - 1)

            img1 = cv2.imread(os.path.join(args.dataset_path, img_name), cv2.IMREAD_GRAYSCALE)
            img2 = cv2.imread(os.path.join(args.dataset_path, img_name.replace('_c1_', '_c2_')), cv2.IMREAD_GRAYSCALE)

            roi1 = crop_to_roi(img1, (cur_x, cur_y), 128)
            roi2 = crop_to_roi(img2, (cur_x, cur_y), 128)

            left_image_batch[0, :, :, 0] = roi1
            right_image_batch[0, :, :, 0] = roi2
    
            # Perform evaluation
            pred_score = model.predict([left_image_batch, right_image_batch])
            pred_class = 1 if pred_score > args.probThreshold else 0

            # Update Z
            pose_z[pose_id][0] = pred_class

            rval += str(pred_class)
    
    now = datetime.now()
    save_file = os.path.join(os.getcwd(), '{}.mat'.format(abs(hash(now))))
    scipy.io.savemat(save_file, variable)
    sys.stdout.write('tnt')
    sys.stdout.write(save_file)
    sys.stdout.write('result')