function [detModPoses, counter]=get_classification(detModPoses_PreviousModule, counter, z_string)
    
    detModPoses = struct;
    detModPoses.modName = 'DL-Classification';
    detModPoses.PoseX = [];
    detModPoses.PoseY = [];
    detModPoses.PoseZ = [];
    
    if isempty(detModPoses_PreviousModule.PoseX)
        return;
    end
    
    for i=1:length(detModPoses_PreviousModule.PoseX)
        PoseX = detModPoses_PreviousModule.PoseX(i);
        PoseY = detModPoses_PreviousModule.PoseY(i);
        PoseZ = str2double(char(z_string(counter)));
        counter = counter + 1;
        
        detModPoses.PoseX = [detModPoses.PoseX; PoseX];
        detModPoses.PoseY = [detModPoses.PoseY; PoseY];
        detModPoses.PoseZ = [detModPoses.PoseZ; PoseZ];
    end
    

end