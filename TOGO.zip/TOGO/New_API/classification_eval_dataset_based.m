function [z_string] = classification_eval_dataset_based(module, dataset_path, ALL_detModPoses_path, common)
        
    use_python = fullfile(pwd, 'E2E_classification_Eval.py');
    
    systemCommand1 = common.python_path;
    systemCommand2 = [' ' use_python];
    systemCommand3 = [' ' module.module_path ' ' ALL_detModPoses_path ' ' dataset_path ' ' num2str(module.probThresh)];
    systemCommand = [systemCommand1 systemCommand2 systemCommand3];

    [~, commandOut] = system(systemCommand);
    tmp1 = extractAfter(commandOut , 'tnt');
    z_string = extractBefore(tmp1 , 'result');

end