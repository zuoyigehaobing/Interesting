function GT = readSGT(SGTfile, filter_file_path)
    
    % Input: 
    %   SGT file full path
    %   filter_file full path
    % Output: structure containing SGT information
    
    % read and create the filter
    [~, ~, filters]= createFilter(filter_file_path);
    
    % read the sgt file
    SGTfileID = fopen(SGTfile,'r');
    if SGTfileID == -1
        error('SGT file not found: %s', SGTfile);
    end
    
    % Populate GT structure; output
    GT = struct;
    line = fgetl(SGTfileID);
    
    row = 1;
    
    % Temporary workaround: Check if line contains GT headers; use them if they exist
    if strcmp( line(1:12), 'PictureName,')
        GT_headers = strsplit(line, ',', 'CollapseDelimiters', 0);
        
        line_c1 = fgetl(SGTfileID);
        line_c2 = fgetl(SGTfileID);
        
        while ~isequal(line_c1, -1) && ~isequal(line_c2, -1)

        cellArray1 = strsplit(line_c1, ',', 'CollapseDelimiters', 0);
            cellArray2 = strsplit(line_c2, ',', 'CollapseDelimiters', 0);
            c1_idx = row;
            c2_idx = row + 1;
            
            for col = 1:length(GT_headers)

              if isempty(GT_headers{col}) % Skip if header is empty
                continue;
              end
              
              header = GT_headers{col}; % char/string
              
              % record c1 fields
				      str    = cellArray1{col}; % char/string; read directly from SGT
				      [~, isNumeric] = str2num(str); % check if str is convertible to numeric

				      if isNumeric
                eval( ['GT(c1_idx).' header ' = str2num(str);'] ); % evaluate GT(c1_idx).header = str2num(entry) ; as numerical
				      else
                eval( ['GT(c1_idx).' header ' =         str ;'] ); % evaluate GT(c1_idx).header =         entry; as string
			        end
              
              % record c2 fields
              str    = cellArray2{col}; % char/string; read directly from SGT
				      [~, isNumeric] = str2num(str); % check if str is convertible to numeric

				      if isNumeric
                eval( ['GT(c2_idx).' header ' = str2num(str);'] ); % evaluate GT(c2_idx).header = str2num(entry) ; as numerical
				      else
                eval( ['GT(c2_idx).' header ' =         str ;'] ); % evaluate GT(c2_idx).header =         entry; as string
			        end

            end
            
            line_c1 = fgetl(SGTfileID);
            line_c2 = fgetl(SGTfileID);
            
            check_val = satisfy_filter_conditions(GT(c1_idx), filters) && satisfy_filter_conditions(GT(c2_idx), filters);
            
            % Make sure that c1 and c2 are correct
            % if ~contains(GT(c1_idx).PictureName, '_c1_') || ~contains(GT(c2_idx).PictureName, '_c2_')
            %     error('SGT File Not Well Formed, c1 or c2 for some image missing ...');
            % end
            
            if ~check_val
              GT(c2_idx) = []; GT(c1_idx) = [];
            else
              row = row + 2;
            end
            
        end
    
    
    else % Use default hardcoded GT headers and order
    
        error('%s does not contain column headers or it does not starts with "PictureName" !!!', SGTfile);
                
    end

    fclose(SGTfileID);
    
end




function [filters, filterCell, filterCell2] = createFilter(filterFile);
    % Create a filter structure by parsing through the filter text file. Format:
    % filter.Common = {"BoundaryOnly"}
    % filter.LightType = {"Indoor", "Outdoor"}
    % filter.PoseX = [260, 300] = [val] or [min max]
    
    % Alternatively, create Nx2 filter CELL ARRAY. Format:
    % { "Common",       {"BoundaryOnly"};
    %   "LightType",    {"Indoor", "Outdoor"};
    %   "PoseX",        [260,300] }
    
    
    fileID = fopen(filterFile, 'r');
    line = fgetl(fileID);
    filters = struct;
    filterCell = {};
    filterCell2 = {};
 
    % For each line in the filter file:
    while ~isequal(line, -1)
        if length(line) <= 3 line = fgetl(fileID); continue; end % empty(ish) line
        if line(1) == ';'    line = fgetl(fileID); continue; end % Comment
        line = strsplit(line, {' ', '=', ','});
        if length(line) <= 1 line = fgetl(fileID); continue; end % No filter value 
                
        switch line{1};
            case {'Common','PJImage','LightType','TesterName','TesterGender','SkinColour','FingerSize','NailColour','Memo'};
                values = '{';
                for i = 2:length(line) values = [values, '"', line{i}, '",']; end
                values(end) = '}';
                
            case {'Index','PoseX','PoseY','PoseZ','AngleTheta','AnglePhi','IRPowerW','FingerPresent','Lux'};
                values = '[';
                for i = 2:length(line) values = [values, line{i}, ',']; end
                values(end) = ']';
        end
        
        filterCell{end+1, 1} = line{1};
        filterCell{end,   2} = eval(values); % Cell Array
        
        filterCell2{end+1} = { line{1} };
        filterCell2{end}{2} = eval(values); % differently organized cell array
        eval( ['filters.', line{1}, '= ''', values, ''';'] ) %Structure
        
        line = fgetl(fileID);

    end
    
end



function iFilt = satisfy_filter_conditions(GT_img, filters)
  
  iFilt = 1; 
  
  
  for f = 1:length(filters)
    
      ppty = filters{f}{1};
      vals = filters{f}{2};
            
      switch ppty
          case 'PJImage';      if ~matchStr(GT_img.PJImage, vals)     iFilt = 0; end
          case 'Index';        if ~matchInt(GT_img.Index, vals)       iFilt = 0; end
          case 'LightType';    if ~matchStr(GT_img.LightType, vals)   iFilt = 0; end
          case 'TesterName';   if ~matchStr(GT_img.TesterName, vals)  iFilt = 0; end
          case 'TesterGender'; if ~matchStr(GT_img.TesterGender, vals) iFilt = 0; end
          case 'SkinColour';   if ~matchStr(GT_img.SkinColour, vals)  iFilt = 0; end
          case 'IRPowerW';     if ~matchInt(GT_img.IRPowerW, vals)    iFilt = 0; end
          case 'FingerSize';   if ~matchStr(GT_img.FingerSize, vals)  iFilt = 0; end
          case 'NailColour';   if ~matchStr(GT_img.NailColour, vals)  iFilt = 0; end
          case 'Memo';         if ~matchStr(GT_img.Memo, vals)        iFilt = 0; end                    
          case 'PoseX';        if ~matchInt(GT_img.GT_X, vals)        iFilt = 0; end
          case 'PoseY';        if ~matchInt(GT_img.GT_Y, vals)        iFilt = 0; end
          case 'PoseZ';        if ~matchInt(GT_img.GT_Z, vals)        iFilt = 0; end
          case 'AngleTheta';   if ~matchInt(GT_img.GT_Theta, vals)    iFilt = 0; end                
          case 'AnglePhi';     if ~matchInt(GT_img.GT_Phi, vals)      iFilt = 0; end
          case 'FingerPresent';if ~matchInt(GT_img.FingerPresent, vals) iFilt = 0; end
          case 'Lux';          if ~matchInt(GT_img.Lux, vals)         iFilt = 0; end
          case 'Sequence';     if ~matchInt(GT_img.Sequence, vals)    iFilt = 0; end
          
      end
      
      if iFilt == 0 break; end
      
  end
  
  
  
end


function iMatch = matchStr(GTval, filterVals)
    % Return 1/0 if GTval matches the filters
    iMatch = 0;
    
    if (isempty(GTval) || isequal(filterVals,{}) || isequal(filterVals,{""}))
        iMatch = 1; 
        return; 
    end 
    
    for i = 1:length(filterVals)
        if isequal(string(GTval), string(filterVals{i}))
            iMatch = 1;
            return;
    end; end
    
end

function iMatch = matchInt(GTval, filterVals)
    % Return 1/0 if GTval matches the filters
    iMatch = 0;
    
    if (isempty(GTval) || isempty(filterVals))
        iMatch = 1; 
        return;
    end
    
    if GTval >= filterVals(1) && GTval <= filterVals(end)
        iMatch = 1;
        return;
    end
    
end