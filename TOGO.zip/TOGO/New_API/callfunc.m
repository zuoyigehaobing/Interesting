function [varargout] = callfunc(function_path, varargin)
    % Given full path to function and input args: 
    % switch path to folder containing function
    % call function with input args, obtain output
    % switch back to original path
    
    orig_dir = pwd;
        
    [funcpath, funcname, ext] = fileparts(function_path);
    
    if ~isequal(funcpath, '') cd(funcpath); end
    
    func_handle = eval(['@',funcname]);
    [varargout{1:nargout}] = func_handle(varargin{:});

    if ~isequal(funcpath, '') cd(orig_dir); end
    
end