function ROI_Eval(module, save_dir, common)

% ROI Evaluation Module

% INPUTS:
%     (1) module: roi module struct
%           .type           - 'ROI'
%           .name           - e.g. 'ROI1420'
%           .module_path    - full file path of the main ROI function
%           .api_type       - One of 'FeedGT', 'Bkg', 'BkgBlk'
%     (2) save_dir: top-level folder where you save the results
%     (3) common: common field in configuration file, includes
%           .eval_basefolder  - higher level folder where you save eval results of all modules
%           .python_path      - where to load your Python interpreter
%           .datasets         - evaluation lists
%           .MinimumHoverZ    - (*) Used in Reporting: when GT_Z >= MinimumHoverZ, it's hover
%           .dR               - (*) Used in Reporting: When Err_R <= dR, it's correct in localization

  
% ACTIONS:
%   (1) For each dataset in the evaluation list, run ROI evaluation on it
%   (2) Support Report Generation



  %% Loop over datasets:
  for dataset_idx = 1:length(common.datasets)
    
    % Load SGT and the Filter File
    dataset_path   = common.datasets(dataset_idx).dataset_path;
    dataset_name   = common.datasets(dataset_idx).dataset_name;
    is_seq_data   = common.datasets(dataset_idx).is_seq_data;
    detect_module = module.module_path;
    sgt_filepath = fullfile(dataset_path, common.datasets(dataset_idx).sgt_filename);
    GT = readSGT(sgt_filepath, common.datasets(dataset_idx).filter_file);

    % Eval base folder for this dataset
    eval_folder = fullfile(save_dir, common.datasets(dataset_idx).dataset_name);
    mkdir(eval_folder); 
    
    % Clear previous ALL_detModPoses if exists, reset nImgPairs
    clear ALL_detModPoses;
    nImgPairs = 0;
    
    % Display current dataset
    fprintf('\n[%s] Eval on [%s] (%d/%d)\n', module.name, dataset_name, dataset_idx, length(common.datasets));
    fprintf('Total images: [%d]. Imgs processed:\n', length(GT));

    
    % Loop over images and do detection
    for i = 1:length(GT)
      
      % -- Display Loop progress
      if ismember(i, round(linspace(1,length(GT),30)) ), fprintf('%d..', i); end
      
      % -- READ c1 images (not c2, not bkground / black) 
      if isempty(strfind(GT(i).PictureName, '_c1')) 
          continue; 
      end
      
      GT_idx1 = i; GT_c1 = GT(GT_idx1); imgname_c1 = GT_c1.PictureName;
      GT_idx2 = i + 1; GT_c2 = GT(GT_idx2); imgname_c2 = GT_c2.PictureName;
      
      % Process GT to get the location for the image pair, convert GT_Z into touch/hover
      GT = process_GT(GT, GT_idx1, 'AVG', common.MinimumHoverZ);
      
      % Read c1/c2 images
      img_c1 = im2uint8(imread(fullfile(dataset_path, imgname_c1)));
      img_c2 = im2uint8(imread(fullfile(dataset_path, imgname_c2)));
      if size(img_c1, 1) > 800
          img_c1 = img_c1(51:850, 51:1330, :); img_c2 = img_c2(51:850, 51:1330, :);
      end
      if size(img_c1, 3) == 1 % convert grayscale to RGB
        img_c1(:,:,2) = img_c1(:,:,1); img_c1(:,:,3) = img_c1(:,:,1);
        img_c2(:,:,2) = img_c2(:,:,1); img_c2(:,:,3) = img_c2(:,:,1);
      end
      
      % Load Blk and BKG images if necessary, if not required by the api, it won't load anything
      [bkg_c1, bkg_c2, bkgname_c1] = get_bkg(module.api_type, common.datasets(dataset_idx), GT_c1);
      [blk_c1, blk_c2, blkname_c1] = get_blk(module.api_type, common.datasets(dataset_idx), GT_c1);
      
      % Skip if the current image is black image or bkg image
      if strcmp(imgname_c1, blkname_c1) || strcmp(imgname_c1, bkgname_c1)     
          continue; 
      end
      
      % Run detection; possibly pass in background and/or black image too
      tic;
      if strcmp(module.api_type, 'FeedGT') 
        detModPoses = callfunc(detect_module, GT(GT_idx1));
      elseif ~is_seq_data && strcmp(module.api_type, 'Bkg') 
        detModPoses = callfunc(detect_module, img_c1, img_c2, bkg_c1, bkg_c2);
      elseif ~is_seq_data && strcmp(module.api_type, 'BkgBlk') 
        detModPoses = callfunc(detect_module, img_c1, img_c2, bkg_c1, bkg_c2, blk_c1, blk_c2);
      elseif is_seq_data
        
        if contains(dataset_name, 'leftbottom')
          ROI_left = 1;
          ROI_right = 552;
          ROI_top = 497;
          ROI_bot = 800;
        elseif contains(dataset_name, 'lefttop')
          ROI_left = 1;
          ROI_right = 608;
          ROI_top = 1;
          ROI_bot = 592;                    
        elseif contains(dataset_name, 'rightbottom')
          ROI_left = 681;
          ROI_right = 1280;
          ROI_top = 497;
          ROI_bot = 800;
        elseif contains(dataset_name, 'righttop')
          ROI_left = 593;
          ROI_right = 1280;
          ROI_top = 1;
          ROI_bot = 504;
        else
          error('ROI type not found !');
        end
        
        if strcmp(module.api_type, 'Bkg') 
          detModPoses = callfunc(detect_module, img_c1, img_c2, bkg_c1, bkg_c2, ROI_left, ROI_right, ROI_top, ROI_bot);
        elseif strcmp(module.api_type, 'BkgBlk')
          detModPoses = callfunc(detect_module, img_c1, img_c2, bkg_c1, bkg_c2, blk_c1, blk_c2, ROI_left, ROI_right, ROI_top, ROI_bot);
        else 
          error(['ROI Api ' module.api_type ' Not Implemented']);
        end
      
      else
        error(['ROI Api ' module.api_type ' Not Implemented']);
      end
      
      % Collect Detection Time
      t_detect = toc;

      % Overwrite modName of the Det
      detModPoses.modName = 'ROI';
      
      % Save detection results so far in a MAT variable
      nImgPairs = nImgPairs + 1;
      ALL_detModPoses(nImgPairs).PictureName = imgname_c1;
      ALL_detModPoses(nImgPairs).detModPoses = detModPoses;
      ALL_detModPoses(nImgPairs).t_detect    = t_detect;
      ALL_detModPoses(nImgPairs).c1_index    = GT_idx1;
        

      
    end  
    
    % Save detection results (raw; without analysis)
    fprintf('\n');
    writeDetResCSV(eval_folder, ALL_detModPoses, GT);
    
        
    
  
  end

end





%%%%%%%%%%%%%%%%%%%%%% Helper functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [bkg_c1, bkg_c2, bkgname_c1] = get_bkg(api_type, dataset, GT_c1)
    
  % -- Find and load background/black image if necessary 
  if strcmp(api_type, 'Bkg') || strcmp(api_type, 'BkgBlk')
      
      % Missing
      if strcmp(dataset.bkgname_c1, 'missing')
          bkgname_c1 = 'missing';
          bkg_c1 = im2uint8(zeros(800,1280,3));  % why not 62?
          bkg_c2 = im2uint8(zeros(800,1280,3));  
      
      % read from SGT
      elseif strcmp(dataset.bkgname_c1, 'sgt')
      
          bkgname_c1 = GT_c1.BkgImageName;
          bkg_c1 = im2uint8(imread(fullfile(dataset.dataset_path, bkgname_c1)));

          bkgname_c2 = strrep(bkgname_c1, '_c1', '_c2');
          bkg_c2 = im2uint8(imread(fullfile(dataset.dataset_path, bkgname_c2))); 
          
      else % image specified in parameter file
          
          bkgname_c1 = dataset.bkgname_c1;
          bkg_c1 = im2uint8(imread(fullfile(dataset.dataset_path, bkgname_c1)));

          bkgname_c2 = strrep(bkgname_c1, '_c1', '_c2');
          bkg_c2 = im2uint8(imread(fullfile(dataset.dataset_path, bkgname_c2))); 
      
      end
      
      % Adjust the bkg image size
      if exist('bkg_c1', 'var') && size(bkg_c1, 1) > 800
          bkg_c1 = bkg_c1(51:850, 51:1330, :);    
          bkg_c2 = bkg_c2(51:850, 51:1330, :);    
      end
      
  else
      bkg_c1 = [];
      bkg_c2 = [];
      bkgname_c1 = '';
  end
  
end



function [blk_c1, blk_c2, blkname_c1] = get_blk(api_type, dataset, GT_c1)
    
    
    % -- Find and load black image if necessary
    if strcmp(api_type, 'BkgBlk')
      
        % Missing BLK
        if strcmp(dataset.blkname_c1, 'missing')
            blkname_c1 = 'missing';
            blk_c1 = im2uint8(zeros(800,1280,3));
            blk_c2 = im2uint8(zeros(800,1280,3)); 
        
        % Read from SGT
        elseif strcmp(dataset.blkname_c1, 'sgt')
            blkname_c1 = GT_c1.BlkImageName;
            blk_c1 = im2uint8(imread(fullfile(dataset.dataset_path, blkname_c1)));

            blkname_c2 = strrep(blkname_c1, '_c1', '_c2');
            blk_c2 = im2uint8(imread(fullfile(dataset.dataset_path, blkname_c2))); 
            
        else % Black image specified in parameter file
            blkname_c1 = dataset.blkname_c1;
            blk_c1 = im2uint8(imread(fullfile(dataset.dataset_path, blkname_c1)));

            blkname_c2 = strrep(blkname_c1, '_c1', '_c2');
            blk_c2 = im2uint8(imread(fullfile(dataset.dataset_path, blkname_c2))); 
        end
        
        % Adjust the dimension for black image
        if exist('blk_c1', 'var') && size(blk_c1, 1) > 800
            blk_c1 = blk_c1(51:850, 51:1330, :);    
            blk_c2 = blk_c2(51:850, 51:1330, :);    
        end

    
    else
      blk_c1 = [];
      blk_c2 = [];
      blkname_c1 = '';
    end  
  
end
