function [GT] = process_GT (GT, GT_idx1, mode, minimumHoverZ)

% function to process Ground Truth informations
%
% INPUTS:
% (1) GT: Struct that saves all ground truth fields
% (2) GT_idx1, row number of current C1 image
% (3) mode: how you calculate GT_X and GT_Y for this image pair


%   ACTIONS:
%   (1) convert x1, y1, x2, y2 into Matlab Frame Coordinate and save it in C1's GT field
%   (2) compute x,y in Matlab Frame coordinate for the current image pair
%           if mode == 'AVG': x = (x1 + x2) / 2, y = (y1 + y2) / 2; 
%                       it has value iff both (x1, y1), (x2, y2) are not None
%           if mode == 'C2':  x = x1 * 0 + x2 * 1; y = y1 * 0 + y2 * 1;
%                       it has value iff both (x1, y1), (x2, y2) are not None
%   (3) Compute Pose Z in Matlab Frame (touch=1/hover=0)
%           if GT_Z >= minimumHoverZ -> hover (0)
%           else touch (1)
%
%
%   Assumption:
%   GT_idx2 = GT_idx1 + 1;

% Obtain GT_idx2
GT_idx2 = GT_idx1 + 1;
GT_c1 = GT(GT_idx1); imgname_c1 = GT_c1.PictureName;
GT_c2 = GT(GT_idx2); imgname_c2 = GT_c2.PictureName;
if ~ strcmp(imgname_c1, strrep(imgname_c2, '_c2_', '_c1_'))
  error('Image C1 and Image C2 are not connected');
end

    

% Record Some C1, C2 information

GT(GT_idx1).GT_X_C1_Mat = 1281 - GT(GT_idx1).GT_X;  % Matlab Frame : origin at top-left, origin point coordinate = (1, 1)
GT(GT_idx1).GT_Y_C1_Mat = 801  - GT(GT_idx1).GT_Y;  % Matlab Frame : origin at top-left, origin point coordinate = (1, 1)
GT(GT_idx1).GT_X_C2_Mat = 1281 - GT(GT_idx2).GT_X;  % Matlab Frame : origin at top-left, origin point coordinate = (1, 1)
GT(GT_idx1).GT_Y_C2_Mat = 801  - GT(GT_idx2).GT_Y;  % Matlab Frame : origin at top-left, origin point coordinate = (1, 1)
GT(GT_idx1).GT_Z_MM = GT(GT_idx1).GT_Z;

% Record Ground Truth Information
if strcmp(mode, 'AVG')
  
  GT(GT_idx1).GT_X = 1281 - (GT(GT_idx1).GT_X + GT(GT_idx2).GT_X) / 2; % Convert from Edge SGT to Matlab Frame
  GT(GT_idx1).GT_Y = 801  - (GT(GT_idx1).GT_Y + GT(GT_idx2).GT_Y) / 2;  % Convert from Edge SGT to Matlab Frame
  GT(GT_idx1).GT_Z = (GT(GT_idx1).GT_Z + GT(GT_idx2).GT_Z) / 2;

elseif strcmp(mode, 'C2')
  GT(GT_idx1).GT_X = 1281 - (GT(GT_idx1).GT_X * 0 + GT(GT_idx2).GT_X); % Convert from Edge SGT to Matlab Frame
  GT(GT_idx1).GT_Y = 801  - (GT(GT_idx1).GT_Y * 0 + GT(GT_idx2).GT_Y);  % Convert from Edge SGT to Matlab Frame
  GT(GT_idx1).GT_Z = (GT(GT_idx1).GT_Z * 0 + GT(GT_idx2).GT_Z);

else
  error('Process GT Mode Error');
end


% Record Touching Information
GT(GT_idx1).GT_Z = (( GT(GT_idx1).GT_Z ) < minimumHoverZ) * 1; % Convert from GT_Z to GT_Z (Matlab Frame), (value -> binary touch | hover) 


end