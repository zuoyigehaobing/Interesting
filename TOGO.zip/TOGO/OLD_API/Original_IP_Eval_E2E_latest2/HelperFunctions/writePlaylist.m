function pl_file = writePlaylist(dataset_path, filter_file_path, save_path)
    

    % Input:
    % dataset_path: path to raw imgs folder 
    % filter_file: full path of .txt filter file (or just filename if in cwd)
    % save_path: where to save playlist
    
    % Output: 
    % pl_file: path to playlist file (also saves to save_path)
    current_dir = pwd;
    imgs = getFilesRecursively(dataset_path, '', struct);
    cd(current_dir);
    
    [~, ~, filters]= createFilter(filter_file_path);
    GT = readSGT(dataset_path);
    PLimgs = filterImages(imgs, filters, GT);
    pl_file = writePLfile(dataset_path, PLimgs, save_path);
    
end 

           


function lst = getFilesRecursively(root, path, lst)
% function files = getFilesRecursively(rootDir, relPath)
    % Recursively search for all non-folders in "root"
    % Return struct array of paths relative to root
    % array(i).name = relative path of file wrt root
    cd(root);
        
    items = dir();
    
    for i = 3:length(items)
		element = items(i).name;
		
        if exist(element) == 7
            lst = getFilesRecursively(element, fullfile(path, element),  lst);
            cd ..;
        else
            lst(length(lst) + 1).name = fullfile(path, element);
            
        end
    
    end
        

end

    
    
    

function pl_filename = writePLfile(path, PLimgs, save_path)
    % Save PLimgs cell array into a .pl file
    pl_filename = fullfile(save_path, ['images_',datestr(now(), 'yyyymmdd_HHMMSS'), '.pl']);
    fileID = fopen(pl_filename,'wt');
    %fprintf(fileID,'%s\n', path);
    for i = 1:length(PLimgs)
        fprintf( fileID,'%s\n', PLimgs{i} );
    end
    fclose(fileID);
end

function filtImgNames = filterImages(imgs, filters, GT)
    % Filter "imgs" based on "filters"
    
    filtImgNames = {};
    for i = 1:length(imgs)
        
        imgName = imgs(i).name;
        iFilt = 1; 
        
        idx = findImgIdx(GT, imgName);
        if idx == -1 continue; end
        
        for f = 1:length(filters)
            ppty = filters{f}{1};
            vals = filters{f}{2};
            
            GT_img = GT(idx);
            switch ppty
                case 'PJImage';      if ~matchStr(GT_img.PJImage, vals)     iFilt = 0; end
                case 'Index';        if ~matchInt(GT_img.Index, vals)       iFilt = 0; end
                case 'LightType';    if ~matchStr(GT_img.LightType, vals)   iFilt = 0; end
                case 'TesterName';   if ~matchStr(GT_img.TesterName, vals)  iFilt = 0; end
                case 'TesterGender'; if ~matchStr(GT_img.TesterGender, vals) iFilt = 0; end
                case 'SkinColour';   if ~matchStr(GT_img.SkinColour, vals)  iFilt = 0; end
                case 'IRPowerW';     if ~matchInt(GT_img.IRPowerW, vals)    iFilt = 0; end
                case 'FingerSize';   if ~matchStr(GT_img.FingerSize, vals)  iFilt = 0; end
                case 'NailColour';   if ~matchStr(GT_img.NailColour, vals)  iFilt = 0; end
                case 'Memo';         if ~matchStr(GT_img.Memo, vals)        iFilt = 0; end                    
                case 'PoseX';        if ~matchInt(GT_img.GT_X, vals)        iFilt = 0; end
                case 'PoseY';        if ~matchInt(GT_img.GT_Y, vals)        iFilt = 0; end
                case 'PoseZ';        if ~matchInt(GT_img.GT_Z, vals)        iFilt = 0; end
                case 'AngleTheta';   if ~matchInt(GT_img.GT_Theta, vals)    iFilt = 0; end                
                case 'AnglePhi';     if ~matchInt(GT_img.GT_Phi, vals)      iFilt = 0; end
                case 'FingerPresent';if ~matchInt(GT_img.FingerPresent, vals) iFilt = 0; end
                case 'Lux';          if ~matchInt(GT_img.Lux, vals)         iFilt = 0; end
                case 'Sequence';     if ~matchInt(GT_img.Sequence, vals)    iFilt = 0; end
                
                
            end
            
            if iFilt == 0 break; end
        end
        
        if iFilt == 1 filtImgNames{end+1} = imgName; end
            
    end        
end
    
    
function iMatch = matchStr(GTval, filterVals)
    % Return 1/0 if GTval matches the filters
    iMatch = 0;
    
    if (isequal(GTval, "") || isequal(filterVals,{}) || isequal(filterVals,{""}))
        iMatch = 1; 
        return; 
    end 
    
    for i = 1:length(filterVals)
        if isequal(string(GTval), string(filterVals{i}))
            iMatch = 1;
            return;
    end; end
    
end

function iMatch = matchInt(GTval, filterVals)
    % Return 1/0 if GTval matches the filters
    iMatch = 0;
    
    if (isempty(GTval) || isempty(filterVals))
        iMatch = 1; 
        return;
    end
    
    if GTval >= filterVals(1) && GTval <= filterVals(end)
        iMatch = 1;
        return;
    end
    
end
    


function idx = findImgIdx(GT, imgName)
    % Find index corresponding to imgName in GT structure
    for i = 1:length(GT)
        if isequal(GT(i).PictureName, imgName)
            idx = i;
            return; 
    end; end
    idx = -1;
end           

    
function [filters, filterCell, filterCell2] = createFilter(filterFile);
    % Create a filter structure by parsing through the filter text file. Format:
    % filter.Common = {"BoundaryOnly"}
    % filter.LightType = {"Indoor", "Outdoor"}
    % filter.PoseX = [260, 300] = [val] or [min max]
    
    % Alternatively, create Nx2 filter CELL ARRAY. Format:
    % { "Common",       {"BoundaryOnly"};
    %   "LightType",    {"Indoor", "Outdoor"};
    %   "PoseX",        [260,300] }
    
    
    fileID = fopen(filterFile, 'r');
    line = fgetl(fileID);
    filters = struct;
    filterCell = {};
    filterCell2 = {};
 
    % For each line in the filter file:
    while ~isequal(line, -1)
        if length(line) <= 3 line = fgetl(fileID); continue; end % empty(ish) line
        if line(1) == ';'    line = fgetl(fileID); continue; end % Comment
        line = strsplit(line, {' ', '=', ','});
        if length(line) <= 1 line = fgetl(fileID); continue; end % No filter value 
                
        switch line{1};
            case {'Common','PJImage','LightType','TesterName','TesterGender','SkinColour','FingerSize','NailColour','Memo'};
                values = '{';
                for i = 2:length(line) values = [values, '"', line{i}, '",']; end
                values(end) = '}';
                
            case {'Index','PoseX','PoseY','PoseZ','AngleTheta','AnglePhi','IRPowerW','FingerPresent','Lux'};
                values = '[';
                for i = 2:length(line) values = [values, line{i}, ',']; end
                values(end) = ']';
        end
        
        filterCell{end+1, 1} = line{1};
        filterCell{end,   2} = eval(values); % Cell Array
        
        filterCell2{end+1} = { line{1} };
        filterCell2{end}{2} = eval(values); % differently organized cell array
        eval( ['filters.', line{1}, '= ''', values, ''';'] ) %Structure
        
        line = fgetl(fileID);

    end
    
end