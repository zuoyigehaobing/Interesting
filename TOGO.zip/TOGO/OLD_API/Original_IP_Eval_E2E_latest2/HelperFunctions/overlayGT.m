function img = overlayGT(img, GT_img, PoseX, PoseY, PoseZ, Pose_labels, dR)
    
    GT_X = GT_img.GT_X;
    GT_Y = GT_img.GT_Y;
    GT_Z = GT_img.GT_Z;
    
    % Overlay GT with large green circle
    if isempty(GT_X) || isnan(GT_X(1)) || GT_X(1) == -1, GT_X = []; end 
        
    for i = 1:length(GT_X)
        
        if GT_Z(i) == 0, thickness = 1.1;
        else,            thickness = 0.6;
        end
        
        img = drawMarker(img, GT_X(i), GT_Y(i), 'o', dR, thickness, 'g', 255);
   
    end 
    
    
    % Overlay pose with small red plus
    if isempty(PoseX) || isnan(PoseX(1)) || PoseX(1) == -1, PoseX = []; end 
    
    for i = 1:length(PoseX)
         
         switch Pose_labels{i}
             case 'Correct detection', colour = 'r';
             case 'Misclassified detection', colour = 'o';
             case 'False detection', colour = 'y';
             otherwise, continue
         end
         
         if PoseZ(i) == 0, size = 7;
         else,             size = 5;
         end
         
         img = drawMarker(img, PoseX(i), PoseY(i), '+', size, 1.1, colour, 255);
         
    end
    
end
