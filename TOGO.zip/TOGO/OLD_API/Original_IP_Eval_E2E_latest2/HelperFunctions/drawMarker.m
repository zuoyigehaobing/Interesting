function img = drawMarker(img, LocX, LocY, mk_typ, mk_siz, mk_thk, mk_col, varargin)

    % Usage: 
    % img = [height x width x 3] image 
    % LocX/LocY: x/y location (MATLAB frame) of marker to draw
    % mk_typ: 'o', 'x', '+'
    % mk_siz / mk_thk: marker size/thickness
    % mk_col: [R G B] values OR ('r')ed, (g)reen, (b)lue, (w)hite, (o)range, (y)ellow, blac(k). 
    % varargin{1}:  multiplier for RGB values (e.g. 255) in case image is not type double
    % ---> only valid if mk_col is passed as 'r', 'g', 'b' etc; not [0.1 0.2 0.5]

    % Returns:
    % img, with a marker overlaid at the specified location
    
    % Convert grayscale to RGB images in order to overlaid coloured markers
    if size(img, 3) == 1
        img(:,:,2) = img(:,:,1);
        img(:,:,3) = img(:,:,1);
    end
    
    LocX = round(LocX);
    LocY = round(LocY);
    
    
    if nargin >= 8, multiplier = varargin{1};
    else,           multiplier = 1;
    end

    imgWidth  = size(img,2);
    imgHeight = size(img,1);
    
    if isnan(LocX) || isnan(LocY), return; end
    if LocX == -1  || LocY == -1,  return; end

    % Set marker colour if passed as a char
    if ischar(mk_col)
        switch mk_col
            case 'r', mk_col = multiplier * [1,0,0];
            case 'g', mk_col = multiplier * [0,1,0];
            case 'b', mk_col = multiplier * [0,0,1];
            case 'w', mk_col = multiplier * [1,1,1];
            case 'o', mk_col = multiplier * [255,135,20]/255; % orange
            case 'y', mk_col = multiplier * [241,211, 1]/255; % yellow
            case 'k', mk_col = multiplier * [0,0,0];
        end
    end
    
    if isequal(mk_typ, 'o')
        
        for dx = round( [-mk_siz-mk_thk : 1 : mk_siz+mk_thk] )
        for dy = round( [-mk_siz-mk_thk : 1 : mk_siz+mk_thk] )
            if  abs(sqrt((dx^2 + dy^2)) -  mk_siz) < mk_thk; 
                if ~isOutOfBound(LocX+dx, LocY+dy, imgWidth, imgHeight)
                    img( LocY+dy, LocX+dx, :) = mk_col;
                end
            end
        end 
        end
        
        
    elseif isequal(mk_typ, 'x')
        
        for dx = round( [-mk_siz:1:mk_siz] )
        for dy = round( [-mk_siz:1:mk_siz] )
            if abs(abs(dx)-abs(dy)) < mk_thk 
                if ~isOutOfBound(LocX+dx, LocY+dy, imgWidth, imgHeight)
                    img( LocY+dy, LocX+dx, :) = mk_col;
                end
            end
        end
        end
    
    
    elseif isequal(mk_typ, '+')

        for dx = round( [-mk_siz-mk_thk : 1 : mk_siz+mk_thk] )
        for dy = round( [-mk_siz-mk_thk : 1 : mk_siz+mk_thk] )
            if abs(dx) < mk_thk || abs(dy) < mk_thk
                if ~isOutOfBound(LocX+dx, LocY+dy, imgWidth, imgHeight)
                    img( LocY+dy, LocX+dx, :) = mk_col;
                end
            end
        end
        end
    
    
    end
       

    
    
    
end


function res = isOutOfBound(LocX, LocY, imgWidth, imgHeight)

    % return 1 if the proposed location (LocX/Y) is out of bound for [imgHeight x imgWidth x N] image

    if  LocX < 1 || LocX > imgWidth || ...
        LocY < 1 || LocY > imgHeight
        res = 1;
    else
        res = 0;
    end
    
end