function [PLimgs] = readPlaylist(pl_file)
    
    % Input: datapath (C:\path\to\images\folder)
    % path to "images.pl" file; format:
        % imgnameA_c1.png
        % imgnameA_c2.png
        % imgnameB_c1.png
        % imgnameB_c2.png
        % ...
        
    % Output: 
    % path: to folder containing images
    % cell array imgs: {"imgnameA_c1.png","imgnameA_c2.png", "imgnameB_c1.png"...}
    
    fileID = fopen(pl_file, 'r');
%     path = fgetl(fileID);
    line = fgetl(fileID);
    PLimgs = {};
    while ~isequal(line, -1)
        PLimgs{end+1} = line;
        line = fgetl(fileID);
    end
    fclose(fileID);

end