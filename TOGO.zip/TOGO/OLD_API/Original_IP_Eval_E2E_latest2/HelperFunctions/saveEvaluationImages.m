function saveEvaluationImages(img_c1, img_c2, GT_img, detModRes, detModIdx, dR, eval_imgs_folder, imgname_c1, imgname_c2, iSaveOrig)
    

%    GT_img.GT_X = GT_img.GT_X + extendPx; % Convert from (MATLAB ignoring ext border)
%    GT_img.GT_Y = GT_img.GT_Y + extendPx; % back to (MATLAB with ext border), for imwrite
    PoseX = detModRes(detModIdx).PoseX;% + extendPx;
    PoseY = detModRes(detModIdx).PoseY;% + extendPx;
    PoseTouch = detModRes(detModIdx).PoseTouch;
    PoseLabels = detModRes(detModIdx).PoseLabels;
    
    nFalse   = detModRes(detModIdx).nFalse;  
    nMissed  = detModRes(detModIdx).nMissed; 
    nCorrect = detModRes(detModIdx).nCorrect;
    
    if ~exist('iSaveOrig','var')
        iSaveOrig = 0;
    end
    

    if iSaveOrig
        img_c1_orig = img_c1;
        img_c2_orig = img_c2;
        if ~exist(fullfile(eval_imgs_folder, 'orig',  fileparts(imgname_c1) ), 'dir')
            mkdir(fullfile(eval_imgs_folder, 'orig',  fileparts(imgname_c1) )       );
        end
        imwrite(img_c1_orig, fullfile(eval_imgs_folder, 'orig', imgname_c1));
        imwrite(img_c2_orig, fullfile(eval_imgs_folder, 'orig', imgname_c2));
    end
    
    img_c1 = overlayGT(img_c1, GT_img, PoseX, PoseY, PoseTouch, PoseLabels, dR );
    img_c2 = overlayGT(img_c2, GT_img, PoseX, PoseY, PoseTouch, PoseLabels, dR );
    
    
    if ~exist(fullfile(eval_imgs_folder, fileparts(imgname_c1) ), 'dir')
        mkdir(fullfile(eval_imgs_folder, fileparts(imgname_c1) )       );
    end
    imwrite(img_c1, fullfile(eval_imgs_folder, imgname_c1));
    imwrite(img_c2, fullfile(eval_imgs_folder, imgname_c2));
    
  
    if nFalse >= 1
        falseFolder = fullfile(eval_imgs_folder, 'False');
        if ~exist(fullfile(falseFolder, fileparts(imgname_c1) ), 'dir')
            mkdir(fullfile(falseFolder, fileparts(imgname_c1) )       );
        end
        
        imwrite(img_c1, fullfile(falseFolder, imgname_c1));
        imwrite(img_c2, fullfile(falseFolder, imgname_c2));
        
        if iSaveOrig
            if ~exist(fullfile(falseFolder, 'orig', fileparts(imgname_c1) ), 'dir')
                mkdir(fullfile(falseFolder, 'orig', fileparts(imgname_c1) )       );
            end
            
            imwrite(img_c1_orig, fullfile(falseFolder, 'orig', imgname_c1));
            imwrite(img_c2_orig, fullfile(falseFolder, 'orig', imgname_c2));
        end
        
    end
    
    if nMissed >= 1
        missedFolder = fullfile(eval_imgs_folder, 'Missed');
        if ~exist(fullfile(missedFolder, fileparts(imgname_c1) ), 'dir')
            mkdir(fullfile(missedFolder, fileparts(imgname_c1) )       );
        end
        imwrite(img_c1, fullfile(missedFolder, imgname_c1));
        imwrite(img_c2, fullfile(missedFolder, imgname_c2));
        
        if iSaveOrig
            if ~exist(fullfile(missedFolder, 'orig', fileparts(imgname_c1) ), 'dir')
                mkdir(fullfile(missedFolder, 'orig', fileparts(imgname_c1) )       );
            end
            
            imwrite(img_c1_orig, fullfile(missedFolder, 'orig', imgname_c1));
            imwrite(img_c2_orig, fullfile(missedFolder, 'orig', imgname_c2));
        end
               
        
    end
    
    if nCorrect > 0 && nFalse + nMissed == 0
        correctFolder = fullfile(eval_imgs_folder, 'Correct');
        if ~exist(fullfile(correctFolder, fileparts(imgname_c1) ), 'dir')
            mkdir(fullfile(correctFolder, fileparts(imgname_c1) )       );
        end                
        imwrite(img_c1, fullfile(correctFolder, imgname_c1));
        imwrite(img_c2, fullfile(correctFolder, imgname_c2));
    end
