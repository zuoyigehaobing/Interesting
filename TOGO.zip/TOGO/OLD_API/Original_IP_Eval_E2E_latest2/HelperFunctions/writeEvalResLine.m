function writeEvalResLine(fileID, GT_img, detModPoses, t_detect, iVerboseFalsePose)
    
    
    % INPUTS:
    % fileID - (from fopen) of resfile, already open for writing
    % detModPoses - struct containing all detections info (from multiple submodules); including pose labels etc
    % GT_img - struct containing SGT info for one image
    % iVerboseFalsePose - flag to write multiple false poses on separate lines
    
    
    % Note: pose info for multiple modules is written side-by-side in the CSV results file. 
    % But GT labels (far right side of results file) are only written for the LAST detection module)
    
    
    fprintf(fileID, strrep(GT_img.PictureName, '\', '/') );
    
    for poseIdx = 1:max(1, max([detModPoses.nPose]))
        
        % Write pose info for each detection module
        for detModIdx = 1:length(detModPoses)
            
            % Pose summary info for the current detection module
            if poseIdx == 1
                fprintf(fileID, ",%d", detModPoses(detModIdx).nPose          );
                fprintf(fileID, ",%d", detModPoses(detModIdx).nGT            );
                fprintf(fileID, ",%d", detModPoses(detModIdx).nCorrect       );
                fprintf(fileID, ",%d", detModPoses(detModIdx).nMissed        );
                fprintf(fileID, ",%d", detModPoses(detModIdx).nMisclassified );
                fprintf(fileID, ",%d", detModPoses(detModIdx).nFalse         );
            else
                fprintf(fileID, ",,,,,,");
            end
            
            % Info for each individual pose of the current detection module
            if poseIdx == 1 || poseIdx <= detModPoses(detModIdx).nPose
                fprintf(fileID, ",%f", detModPoses(detModIdx).PoseX(poseIdx)      );
                fprintf(fileID, ",%f", detModPoses(detModIdx).PoseY(poseIdx)      );
                fprintf(fileID, ",%f", detModPoses(detModIdx).PoseTouch(poseIdx)      );
                fprintf(fileID, ",%f", detModPoses(detModIdx).Err_Touch(poseIdx)       );
                fprintf(fileID, ",%f", detModPoses(detModIdx).ErrR(poseIdx)       );
                fprintf(fileID, ",%s", detModPoses(detModIdx).PoseLabels{poseIdx} );
            else    
                fprintf(fileID, ",,,,,,");
            end
            
        end


        % Write SGT/timing info (only on first line) ...
        if poseIdx == 1

            fprintf(fileID, ", %f", t_detect);
            
            % ... and do so automatically for all GT fields ...
            GT_fieldnames = fieldnames(GT_img);
            for i = 1:length(GT_fieldnames)
                if  strcmp(GT_fieldnames{i}, 'PictureName') || ...
                    ~isempty(strfind(GT_fieldnames{i}, 'GT_'))
                    % (... except PictureName and GT_*; these are written differently)
                    continue
                end
                
                GT_field = eval(['GT_img.', GT_fieldnames{i}]);
                switch class(GT_field)
                    case {'string', 'char'}
                        fprintf(fileID, ", %s", GT_field);
                    case {'uint8', 'uint16', 'uint32', 'etc'}
                        fprintf(fileID, ", %d", GT_field);
                    case {'float', 'double', 'etc'}
                        fprintf(fileID, ", %f", GT_field);
                end
            end
                    
            % Write GT pose info (X/Y/Z/Angle)
            % If multiple poses, write from left-to-right (not top-down)
            for i = 1:length(GT_img.GT_X) 
                fprintf(fileID, ",%f", GT_img.GT_X(i)      );
                fprintf(fileID, ",%f", GT_img.GT_Y(i)      );
                fprintf(fileID, ",%f", GT_img.GT_Z(i)      );
                try 
                    fprintf(fileID, ",%f", GT_img.GT_Phi(i)    );
                    fprintf(fileID, ",%f", GT_img.GT_Theta(i)  );
                    
                catch
                    fprintf(fileID, ",,");
                end
                fprintf(fileID, ",%f", GT_img.GT_Touch(i));
                fprintf(fileID, ",%f", GT_img.GT_X_C1(i));
                fprintf(fileID, ",%f", GT_img.GT_Y_C1(i));
                fprintf(fileID, ",%f", GT_img.GT_X_C2(i));
                fprintf(fileID, ",%f", GT_img.GT_Y_C2(i));
				% Write GT Pose Label for each detection module
				for ii = 1:length(detModPoses)
					fprintf(fileID, ",%s", detModPoses(ii).GT_labels{i} );
				end
            end
        
        end
        
        fprintf(fileID, "\n");
        
        % If verbosity flag == 0, don't print a new line for each additional false pose
        if ~iVerboseFalsePose && strcmp(PoseLabels{i}, 'False detection')
            break
        end
    end
    
    
end