function writeEvalResHeader(fileID, GT, detModNames, varargin)

    % INPUTS: 
    % fileID: for .csv file opened for (w)riting
    % GT: SGT structure used to write result file headers
    % Detection module names: {'module 1 name', 'module 2 name', 'etc'};
    % varargin: header lines, e.g. eval description. Each entry in varargin will be written on one line only
    
    % ACTIONS: 
    % writes header lines, then column headers in CSV files
    % Does not open or close any fileIDs

    % Write header lines -------------------------------------------------------
    for i = 1:length(varargin)
        text = varargin{i};
        text = strrep(text,        '\', '/');
        text = strrep(text,        '/n', '\n');
        fprintf(fileID, [text, '\n']);
    end
    
    fprintf(fileID, '\n');
    
    
    % Write column headers -----------------------------------------------------
    fprintf(fileID, 'PictureName');
    
    % Pose-specific headers for each detection module
    for i = 1:length(detModNames)
        modName = detModNames{i};
        fprintf( fileID, ',(%d) nPose - %s'                     , i, detModNames{i});
        fprintf( fileID, ',(%d) nGT - %s'                       , i, detModNames{i});
        fprintf( fileID, ',(%d) nCorrect - %s'                  , i, detModNames{i});
        fprintf( fileID, ',(%d) nMissed - %s'                   , i, detModNames{i});
        fprintf( fileID, ',(%d) nMisclassified - %s'            , i, detModNames{i});
        fprintf( fileID, ',(%d) nFalse - %s'                    , i, detModNames{i});
        fprintf( fileID, ',(%d) PoseX (Matlab frame) - %s'      , i, detModNames{i});
        fprintf( fileID, ',(%d) PoseY (Matlab frame) - %s'      , i, detModNames{i});
        fprintf( fileID, ',(%d) PoseTouch (Matlab frame) - %s'  , i, detModNames{i});
        fprintf( fileID, ',(%d) Err_Touch - %s'                     , i, detModNames{i});
        fprintf( fileID, ',(%d) Err_R - %s'                     , i, detModNames{i});
        fprintf( fileID, ',(%d) PoseLabel - %s'                 , i, detModNames{i});
    end
     
    % Detection time header
    fprintf(fileID, ',DetectionTime');     
    
    % SGT file headers    
    GT_fieldnames = fieldnames(GT);
    for i = 1:length(GT_fieldnames)
        if  strcmp(GT_fieldnames{i}, 'PictureName') || ...
            ~isempty(strfind(GT_fieldnames{i}, 'GT_'))
            % (PictureName and GT_* are written differently)
            continue
        end
        fprintf(fileID, ',%s', GT_fieldnames{i});
    end
    
    % GT_* headers
    fprintf( fileID, [               ...
        ',GT_X (Matlab frame)'       ...
        ',GT_Y (Matlab frame)'       ...
        ',GT_Z '                     ...
        ',GT_Phi'                    ...
        ',GT_Theta'                  ...
        ',GT_Touch'                  ...
        ',GT_X_C1'                   ...
        ',GT_Y_C1'                   ...
        ',GT_X_C2'                   ...
        ',GT_Y_C2'                   ]);
		
	for i = 1:length(detModNames)
		fprintf(fileID, ',(%d) GT_Label - %s', i, detModNames{i});
	end
	fprintf(fileID, '\n');
        

end