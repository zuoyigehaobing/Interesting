function ROI_results = load_ROI_detection(loadFolder, dR, dataset_path, dataset_name)
    %{
        Helper Function for ROI_CROP: Used to read the detection result
        from the ROI Model
        0) if did before, load directly
        1) Need the evaluation result of ROI model
        2) Need to load Variables: detectionResults
                                   evalResults_dR={dR}.csv
        3) Insert the PictureName info 
    %}
    
    
    %% STEP1: CHECK THE EXISTENCE OF THE EVALRESULT_DR=DR.CSV AND LOAD
    detectionResults_path = fullfile(loadFolder,'detectionResults', 'detectionResults.mat');
    evalResult_path = fullfile(loadFolder,sprintf('evalResults_dR=%d.mat',dR));
    if exist(detectionResults_path,'file') ~= 2 || exist(evalResult_path,'file') ~= 2 
        fprintf("Please Run Evaluation On the ROI Model First\n"); return;
    end
    
    ALL_detPoses = load(detectionResults_path); ALL_detPoses = ALL_detPoses.ALL_detModPoses;
    evalResult = load(evalResult_path);         evalResult = evalResult.ALL_detModRes;
    
    
    %% STEP2: LOOP OVER ALL IMG TO STORE THE IMAGE NAME INSIDE
    for i=1:size(evalResult.imgStats,2)
        evalResult.imgStats(i).PictureName = ALL_detPoses(i).PictureName;
    end
    
    %% STEP2: CONSTRUCT THE RETURN VARIABLE
    ROI_results = struct;
    ROI_results.dataset_name = dataset_name;
    ROI_results.dataset_path = dataset_path;
    ROI_results.ROI_SIZE = -1;
    ROI_results.images = {};
    
    % Loop over all images and store the informations inside
    for i=1:size(evalResult.imgStats,2)
        cur_image = struct;
        cur_image.PictureName = evalResult.imgStats(i).PictureName;
        if size(evalResult.imgStats(i).detModRes.GT_labels, 1) ~= 0
            cur_image.label = evalResult.imgStats(i).detModRes.GT_labels{1};
        else
            cur_image.label = 'No GT';  % Means no Ground Truth, probably we have detection
        end
        
        cur_image.Poses = {};
        for j = 1:size(evalResult.imgStats(i).detModRes.PoseY,1)
            cur_pose = struct;
            cur_pose.posex = evalResult.imgStats(i).detModRes.PoseX(j);
            cur_pose.posey = evalResult.imgStats(i).detModRes.PoseY(j);
            cur_pose.pose_label = evalResult.imgStats(i).detModRes.PoseLabels(j);
            cur_image.Poses{end+1} = cur_pose;
        end
        ROI_results.images{end+1} = cur_image;
            
        
    end

end
