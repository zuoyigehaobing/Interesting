function createSummaryImages(detModRes_i, ALL_GT, dR, summaryImgName)    
    
    % Inputs:
    % detModRes_i, containing all detection info for ONE detection submodule
    % ALL_GT, containing all gt info
    % dR: correct detection pixel error threshold used to draw GT circles
    % eval_foler: where to save summary images
    
    subgridX = round(linspace(1, 1280, 4));
    subgridY = round(linspace(1, 800,4));

    summaryImg = zeros(800,1280,3);
    summaryImg(:,subgridX,:) = 1;
    summaryImg(subgridY,:,:) = 1;

    %% Create Summary image with markers indicating pose and GT
    
    for i = 1:length(ALL_GT.GT_X)        
        %switch GT_Z
        %    case 'Hover', thickness = 0.6;
        %    case 'Touch', thickness = 1.1;
        %end
        thickness = 1.1;
        colour    = 'g'; % green
        mk_size      = dR;
        marker    = 'o';
        
        summaryImg = drawMarker(summaryImg, ALL_GT.GT_X(i), ALL_GT.GT_Y(i), marker, mk_size, thickness, colour);
    end
    
        
    for i = 1:length(detModRes_i.PoseX)
        
        PoseX = detModRes_i.PoseX(i);
        PoseY = detModRes_i.PoseY(i);
        PoseLabel = detModRes_i.PoseLabels{i};
        
        switch PoseLabel
            case 'Correct detection',       colour = 'r'; % red
            case 'Misclassified detection', colour = 'o'; % orange 
            case 'False detection',         colour = 'y'; % yellow
            case 'No pose found',           continue;
            otherwise, error('Incorrect Pose Labels');
        end
        %switch PoseZ
        %    case 'Hover', size = 5;
        %    case 'Touch', size = 7;
        %end
        mk_size      = 7;
        thickness = 1.1;
        marker    = '+';
        
        summaryImg = drawMarker(summaryImg, PoseX, PoseY, marker, mk_size, thickness, colour);
        
        
    end        

    imwrite(summaryImg, summaryImgName);
    
    
    %% Create summary image with overlaid text
    imshow(summaryImg);
	title('! ! ! DO NOT CLOSE THIS FIGURE ! ! !');
    hold on
    
    % Array of num GTs and CDRs in each subgrid location
    nGTs = zeros(length(subgridY)-1, length(subgridX)-1);
    CDRs = zeros(length(subgridY)-1, length(subgridX)-1);
    

    for iX = 2:length(subgridX)
        for iY = 2:length(subgridY)
            MinX = subgridX(iX-1); MaxX = subgridX(iX);
            MinY = subgridY(iY-1); MaxY = subgridY(iY);
            
            [nCorrectPose, nMisclassifiedPose, nFalsePose, ...
                nCorrectGT,   nMisclassifiedGT,   nMissedGT] = ...
                getSubgridStats(detModRes_i, ALL_GT, MinX, MaxX, MinY, MaxY);
                
            % record # GT and CDR in each subgrid location
            nGTs(iY-1,iX-1) = nCorrectGT + nMisclassifiedGT + nMissedGT;
            CDRs(iY-1,iX-1) = nCorrectPose / nGTs(iY-1,iX-1);    
        
            text1 = ['Correct Pose: ', num2str(nCorrectPose)];
            text1b= ['CDR: ', num2str(CDRs(iY-1,iX-1))];
            text2 = ['Misclassified Pose: ', num2str(nMisclassifiedPose)];
            text3 = ['False Pose: ', num2str(nFalsePose)];
            text4 = ['Correct GT: ', num2str(nCorrectGT)];
            text5 = ['Misclassified GT: ', num2str(nMisclassifiedGT)];
            text6 = ['Missed GT: ', num2str(nMissedGT)];
            
                    
            text(MinX+15, MinY+15, text1, 'FontSize', 8, 'Color','red');
            text(MinX+15, MinY+30, text1b,'FontSize', 8, 'Color','red');
            text(MinX+15, MinY+45, text2, 'FontSize', 8, 'Color',[255,135,20]/255);%orange
            text(MinX+15, MinY+60, text3, 'FontSize', 8, 'Color','yellow');
            text(MinX+15, MinY+75, text4, 'FontSize', 8, 'Color','green');  
            text(MinX+15, MinY+90, text5, 'FontSize', 8, 'Color','green');  
            text(MinX+15, MinY+105,text6, 'FontSize', 8, 'Color','green');  
            

            
            
        end
    end
    
    % Print # GT and CDR in each subgrid location to console
    detModRes_i.modName, nGTs, CDRs
    
    hold off
            
    saveas(gcf, strrep(summaryImgName, '.png', '_metrics.png'));
	title('You can now close this figure.');

end
