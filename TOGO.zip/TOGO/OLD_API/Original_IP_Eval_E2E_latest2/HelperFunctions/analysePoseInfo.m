function detModPoses = analysePoseInfo(GT_img, detModPoses, dR, dTouch) % , extendPx
    
    
    % Input: detection results for an image: 
    % GT_img: full SGT information structure for an image
    % detModPoses: structure returned by detection module containing pose info for each submodule
    % dR, dTouch: CDR thresholds
    
    % no longer required:     
    % extendPx: detected poses are in MATLAB ref frame of image, padded with extendPx on all sides
    
    % Output: detModPoses: structure will be modified to include the following info for each submodule:
    % nPose, nGT, nCorrect, nMisclassified, nFalse, GT_labels, nMissed and:
    % ErrR, ErrZ, PoseLabels, CDR_errs, [PoseX/Y/Z are sorted]
    
    GT_X      = GT_img.GT_X(:);
    GT_Y      = GT_img.GT_Y(:);
    GT_Z      = GT_img.GT_Z(:);
    GT_Phi    = GT_img.GT_Phi(:);
    GT_Theta  = GT_img.GT_Theta(:);
    
    % Shan ---------------------- 20181028
    GT_Touch  = GT_img.GT_Touch(:);
    
    if isnan(GT_X), [GT_X, GT_Y, GT_Z, GT_Phi, GT_Theta, GT_Touch] = deal([]); end
    
    nGT = length(GT_X);
    GT_labels = cell(nGT, 1);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Multiple detection Modules ----------------------------------------------
    for detModIdx = 1:length(detModPoses)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
        % Load X/Y/Z pose, convert from (MATLAB with ext border) to (MATLAB ignoring ext border)
        PoseX = detModPoses(detModIdx).PoseX(:);% - extendPx;
        PoseY = detModPoses(detModIdx).PoseY(:);% - extendPx;
        PoseTouch = detModPoses(detModIdx).PoseTouch(:);
        PoseLabels =  cell(size(PoseX));
        
        nCorrect = 0;
        CDR_errs = [];
        nMissed = 0;
        nMisclassified = 0;
        nFalse = 0;
        nPose = length(PoseX);
        
        %%% ------------------------------------------------------------------------
        %%% For each GT: label as correctly detected, not found at all, or misclassified 
        %%% ------------------------------------------------------------------------
        for GT_idx = 1:length(GT_X)
            
            % Try to find pose corresponding to the GT
            gtx = GT_X(GT_idx);
            gty = GT_Y(GT_idx);
            gtz = GT_Z(GT_idx);
            
            % Shan 20181028
            gttouch = GT_Touch(GT_idx);
            
            ErrX = abs(gtx - PoseX);
            ErrY = abs(gty - PoseY);
            ErrR = sqrt(ErrX.^2 + ErrY.^2);
            
            % Shan 20181028
            % ErrZ = abs(gtz - PoseZ);
            Err_Touch = abs(gttouch - PoseTouch);

            % Sort vectors by lowest to highest Err_R
            sorted = sortrows([ErrR, Err_Touch, PoseX, PoseY, PoseTouch]);
            ErrR = sorted(:,1);
            Err_Touch = sorted(:,2);
            PoseX= sorted(:,3);
            PoseY= sorted(:,4);
            PoseTouch= sorted(:,5);        
            
            PoseNumber = findCorrespondingPose(ErrR, Err_Touch, dR, dTouch); 
            
            % Label the GT as detected, missed or misclassified
            % For detected and misclassified, also label the corresponding pose
            if PoseNumber == -1
                GT_labels{GT_idx} = 'Missed';
                nMissed = nMissed +1;
                
            else
                err_r = ErrR(PoseNumber);
                err_touch = Err_Touch(PoseNumber);
                
                if err_r <= dR && err_touch <= dTouch
                    GT_labels{GT_idx} = 'Correctly detected';
                    PoseLabels{PoseNumber} = 'Correct detection';
                    nCorrect = nCorrect+1;
                    CDR_errs(end+1) = ErrR(PoseNumber);
                
                elseif err_r <= dR && err_touch > dTouch
                    GT_labels{GT_idx} = 'Misclassified';
                    PoseLabels{PoseNumber} = 'Misclassified detection';
                    nMisclassified = nMisclassified+1;
                else
                    error('There''s a bug in GT-pose correspondence')
                end
            
            end
                
        end
        %%% ------------------------------------------------------------------------
        %%% Label remaining Poses as false detections 
        %%% ------------------------------------------------------------------------
        for PoseIdx = 1:length(PoseX)
            
            if isempty(PoseLabels{PoseIdx})
                PoseLabels{PoseIdx} = 'False detection';
                nFalse = nFalse +1;
            end
            
        end
            
        %%% ------------------------------------------------------------------------
        % Edge cases: When there is no pose or no GT found
        %%% ------------------------------------------------------------------------
        
        if nPose == 0
            [PoseX, PoseY, PoseTouch, Err_Touch, ErrR] = deal(-1);
            PoseLabels = {'No pose found'};
        elseif nPose ~=0 && nGT == 0
            [Err_Touch, ErrR] = deal(-1*ones(nPose, 1));
        end
        
        % update detection module results structure with PoseX/Y/Z and pose labels
        % since these will be used while writing to results .csv file
        detModPoses(detModIdx).PoseX = PoseX;
        detModPoses(detModIdx).PoseY = PoseY;
        detModPoses(detModIdx).PoseTouch = PoseTouch;
        detModPoses(detModIdx).PoseLabels = PoseLabels;
        detModPoses(detModIdx).ErrR = ErrR;
        detModPoses(detModIdx).Err_Touch = Err_Touch;
        detModPoses(detModIdx).CDR_errs = CDR_errs;
        
        
        detModPoses(detModIdx).nPose          = nPose;
        detModPoses(detModIdx).nGT            = nGT; % This should be part of the GT structure
        detModPoses(detModIdx).nCorrect       = nCorrect;
        detModPoses(detModIdx).nMissed        = nMissed;
        detModPoses(detModIdx).nMisclassified = nMisclassified;
        detModPoses(detModIdx).nFalse         = nFalse;
        detModPoses(detModIdx).GT_labels      = GT_labels;
        
        
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Multiple detection Modules ----------------------------------------------
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
end

    


%%% ------------------------------------------------------------------------
% SUBFUNCTION DEFINITIONS
%%% ------------------------------------------------------------------------
    

function [PoseNumber] = findCorrespondingPose(sErrR, sErrTouch, dR, dTouch)                                        
    % Given ONE GT (x,y,z) and MULTIPLE poses (xi, yi, zi; i = 1...nPoses)
    % Find the pose that corresponds to the GT. Use the following criteria:
    % dR is the pixel error threshold for a correct pose
    % (1) Find closest pose WITHIN dR with correct touch/no touch label
    % (2) Find closest pose WITHIN dR with incorrect touch/no touch label
    % (3) If closest pose is NOT within dR, there is no corresponding pose. return NaN
    
    if isempty(sErrR) % No pose given
        PoseNumber = -1;
        return
    end
    
    if sErrR(1) > dR % No pose within 10 pixels
        PoseNumber = -1;
        return
        
    else
        PoseNumber = 1; 
        if sErrTouch(PoseNumber) <= dTouch % Closest pose is correctly labelled
            return
        else % Closest pose is incorrectly labelled. Try finding a correctly labelled pose within dR
            for i = 2:length(sErrR)
                if sErrR(i) > dR
                    return
                elseif sErrTouch(i) <= dTouch
                %if sErrR(i) <= dR && sErrZ(i) <= dTouch
                    PoseNumber = i; % next closest pose, within 10 pix, and correct label
                    return
                end
            end
        end
    end
    
   
end