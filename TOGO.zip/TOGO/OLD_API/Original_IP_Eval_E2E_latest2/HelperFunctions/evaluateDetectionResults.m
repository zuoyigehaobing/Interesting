function ALL_detModRes = evaluateDetectionResults(resFileName, dR, dTouch, MinimumHoverZ, classification_thresh, ROI_SIZE, ...
                            ALL_detModPoses, GT, resFileHeaderText, iSaveImgs, dataset_path, eval_imgs_folder)
    
    % Uncomment if using Octave
    % newline = "\n";
    
    % INPUTS:
    % (1) resFileName, where results will be written
    % (2/3) dR/dTouch: CDR thresholds
    % (4) ALL_detModPoses: struct array, containing fields:
    %       .PictureName = string
    %       .detModPose = struct array; output of detection module, containing fields:
    %           .PoseX/Y/Z
    %           .modName = detection submodule name
    % (5) GT: original GT structure
    % (6) resFileHeaderText: header lines to write in results file, contain useful information
    % (7-9) iSaveImgs, dataset_path, eval_imgs_folder: used to read and save images with GT overlaid
    
    % ACTIONS:
    % (1) For each image, parses ALL_detModPoses(image index) to analyze 
    % the detected poses according to dR/dTouch
    
    % (2) Writes analyzed pose info to CSV file and save summary image
    
    % (3) Combines analyzed results for all images, for each detection module
    
    % (4) Writes these combined analyzed results as a summary
    
    
    % Initialize output variables
    ALL_detModRes = struct;
    ALL_t_detect = [];
    nGT = 0;
    
    % Write CSV header
    fileID = fopen(resFileName, 'w');
    detModNames = {ALL_detModPoses(1).detModPoses.modName};
    writeEvalResHeader(fileID, GT, detModNames, resFileHeaderText{:});    
    
    %%% ------------------------------------------------------------------------
    % For each image, analyze detected poses according to dR and dTouch
    % And write results to file
    %%% ------------------------------------------------------------------------
    for picIdx = 1:length(ALL_detModPoses)
        
        % Find corresponding GT for current image
        GT_idx = findImgIdx(GT, ALL_detModPoses(picIdx).PictureName);
        GT_img = GT(GT_idx);
        
        
        % Obtain nCorrect etc by analyzing detModPoses based on dR/dTouch
        detModRes = analysePoseInfo(...
            GT_img, ALL_detModPoses(picIdx).detModPoses, dR, dTouch);
            
        % Update ALL_detModRes.nCorrect, etc; nGT; and detection times
        ALL_detModRes = updateDetModRes(ALL_detModRes, detModRes);
        nGT = nGT + length(GT_img.GT_X);
        ALL_t_detect  = [ALL_t_detect, ALL_detModPoses(picIdx).t_detect];
        
        % Write CSV line
        writeEvalResLine(fileID, GT_img, detModRes, ALL_detModPoses(picIdx).t_detect, 1);
        
        % Save evaluation images, if necessary
        if iSaveImgs
            imgname_c1 = ALL_detModPoses(picIdx).PictureName;
            imgname_c2 = strrep(imgname_c1, '_c1', '_c2');
            img_c1 = imread(fullfile(dataset_path, imgname_c1));
            img_c2 = imread(fullfile(dataset_path, imgname_c2));
            if size(img_c1, 1) > 800 %  ~iUseExtBorder && 
                img_c1 = img_c1(51:850, 51:1330, :);
                img_c2 = img_c2(51:850, 51:1330, :);
            end
            
            for detModIdx = 1:length(detModRes)
                if picIdx == 1
                    eval_imgs_folder_modSpecific{detModIdx} = fullfile(eval_imgs_folder, ...
                        [detModRes(detModIdx).modName '_dR=' num2str(dR)]);
                    mkdir(eval_imgs_folder_modSpecific{detModIdx});
                end
                saveEvaluationImages(img_c1, img_c2,GT_img, detModRes, detModIdx, dR, eval_imgs_folder_modSpecific{detModIdx}, imgname_c1, imgname_c2); % extendPx
            end
        end
    
    end
    
    fclose(fileID);
    
    
    %%% -------------------------------------------------------------------------
    % For each detection module, combined analyzed results for all images
    %%% -------------------------------------------------------------------------
    for detModIdx = 1:length(ALL_detModRes.totals)
        
        nCorrect       = ALL_detModRes.totals(detModIdx).nCorrect       ;
        nMissed        = ALL_detModRes.totals(detModIdx).nMissed        ;
        nMisclassified = ALL_detModRes.totals(detModIdx).nMisclassified ;
        CDR_errs       = ALL_detModRes.totals(detModIdx).CDR_errs       ;
        nFalse         = ALL_detModRes.totals(detModIdx).nFalse         ;
        nImgPairs      = length(ALL_detModPoses)                 ;
    
        ALL_detModRes.totals(detModIdx).CDR          = nCorrect / nGT;
        ALL_detModRes.totals(detModIdx).TouchAcc     = mean(CDR_errs);
        
        MDR_missed                            = nMissed / nGT;
        MDR_misclass                          = nMisclassified / nGT;
        ALL_detModRes.totals(detModIdx).MDR_missed   = MDR_missed;
        ALL_detModRes.totals(detModIdx).MDR_misclass = MDR_misclass;
        ALL_detModRes.totals(detModIdx).MDR          = MDR_missed + MDR_misclass;
        
        FDR_missed                            = nFalse / nImgPairs;
        FDR_misclass                          = nMisclassified / nImgPairs;
        ALL_detModRes.totals(detModIdx).FDR_missed   = FDR_missed;
        ALL_detModRes.totals(detModIdx).FDR_misclass = FDR_misclass;
        ALL_detModRes.totals(detModIdx).FDR          = FDR_missed + FDR_misclass;
    end
 
    %%% -------------------------------------------------------------------------
    %%% Write results to sheet
    %%% -------------------------------------------------------------------------
    
    origFile = strrep(fileread(resFileName), '\', '\\');
    temp = strfind(origFile, newline); titleLength = temp(1);
    
    fileID = fopen(resFileName, 'w');
    fprintf(fileID, origFile(1:titleLength));
        
    fprintf(fileID, "--- Results Summary -----------------------------\n");
    fprintf(fileID, "No. of images,%f\n", nImgPairs);
    fprintf(fileID, "No. of GT,%f\n", nGT);
    fprintf(fileID, "Average Detection Time,%f\n", mean(ALL_t_detect));
    fprintf(fileID, "dR threshold,%d\n", dR);
    fprintf(fileID, "dTouch threshold,%d\n", dTouch);
    % shan
    fprintf(fileID, "MinimumHoverZ,%d\n", MinimumHoverZ);
    fprintf(fileID, "classification_thresh,%d\n", classification_thresh);
    fprintf(fileID, "ROI_SIZE,%d\n", ROI_SIZE);
    fprintf(fileID, "No. of detection modules,%d\n\n", length(ALL_detModRes.totals));
    
    
    summaryText = cell(11, 1 + length(ALL_detModRes.totals));
    
    for detModIdx = 1:length(ALL_detModRes.totals)
        
        summaryText{1, 1}           = "Detection module:     ";
        summaryText{1, detModIdx+1} = ALL_detModRes.totals(detModIdx).modName;
        
        summaryText{2, 1}           = "Number of poses:      ";
        summaryText{2, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).nPose, '%d');
        
        summaryText{3, 1}           = "Correct Detection Rate";
        summaryText{3, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).CDR, '%f');
        
        summaryText{4, 1}           = "False Detection Rate: ";
        summaryText{4, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).FDR, '%f');
        
        summaryText{5, 1}           = "Touch Accuracy:       ";
        summaryText{5, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).TouchAcc, '%f');
        
        
        summaryText{7, 1}           = "Missed Detection Rate:";
        summaryText{7, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).MDR, '%f');
        
        summaryText{8, 1}           = "MDR - GT not found:   ";
        summaryText{8, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).MDR_missed, '%f');
        
        summaryText{9, 1}           = "MDR - misclassified:  ";
        summaryText{9, detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).MDR_misclass, '%f');
        
        summaryText{10,1}           = "FDR - false finger:   ";
        summaryText{10,detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).FDR_missed, '%f');
        
        summaryText{11,1}           = "FDR - misclassified:  ";
        summaryText{11,detModIdx+1} = num2str(ALL_detModRes.totals(detModIdx).FDR_misclass, '%f');
    
    end
    
    for y = 1:size(summaryText,1)
        for x = 1:size(summaryText,2)
            fprintf(fileID, '%s', summaryText{y,x});
            fprintf(fileID, ',');
        end
        fprintf(fileID, '\n');
    end
   
    fprintf(fileID, '\n%s', origFile(titleLength+1:end));
    
    fclose(fileID);
    
    save(strrep(resFileName,'.csv','.mat'), 'ALL_detModRes', '-mat');

end