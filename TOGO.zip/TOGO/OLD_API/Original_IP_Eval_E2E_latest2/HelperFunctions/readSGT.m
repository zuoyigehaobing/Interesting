function GT = readSGT(SGTfile)

    % Input: SGT file full path OR dir containing 'all.sgt' or 'label.sgt'
    % Output: structure containing SGT information
    
    SGTfileID = fopen(SGTfile,'r');
    if SGTfileID == -1
        SGTfileID = fopen(fullfile(SGTfile, 'all.sgt'),'r');
        if SGTfileID == -1
            SGTfileID = fopen(fullfile(SGTfile, 'label.sgt'),'r');
            if SGTfileID == -1
                error('SGT file not found: %s', SGTfile);
            end
        end
    end

    % Populate GT structure; output
    GT = struct;
    line = fgetl(SGTfileID);
    
    row = 0;
    
    % Temporary workaround: Check if line contains GT headers; use them if they exist
    if strcmp( line(1:12), 'PictureName,')
        GT_headers = strsplit(line, ',', 'CollapseDelimiters', 0);
        line = fgetl(SGTfileID);

        while ~isequal(line, -1)
        
            row = row + 1;

            cellArray = strsplit(line, ',', 'CollapseDelimiters', 0);
            
            for col = 1:length(GT_headers)
                
				header = GT_headers{col}; % char/string
                
                if isempty(header)
                    continue;
                end
                
				str    = cellArray{ col}; % char/string; read directly from SGT
				[~, isNumeric] = str2num(str); % check if str is convertible to numeric
				
				if isNumeric, eval( ['GT(row).' header ' = str2num(str);'] ); % evaluate GT(row).header = str2num(entry) ; as numerical
				else,         eval( ['GT(row).' header ' =         str ;'] ); % evaluate GT(row).header =         entry; as string
			    end
				
                % switch GT_headers{col}
                %     case {'PictureName','PJImage','CameraID','Hand','AmbientLightType','PJResolution','TesterName','TesterGender','SkinColour','FingerSize','NailColour','Memo','BkgImageName'} 
                %         eval(['GT(row).' GT_headers{col} ' =          cellArray{' num2str(col) '}  ;' ]);
                %   
                %     case {'Index','GT_X','GT_Y','GT_Z','GT_Phi','GT_Theta','FingerPresent','IRPowerW','AmbientLightLUX','ProjectionSizeInch','Resolution','Contrast','Blur','Noise','Sequence','SequenceClass'}
                %         eval(['GT(row).' GT_headers{col} ' = str2num( cellArray{' num2str(col) '} );' ]);
                % end
            end
            
            line = fgetl(SGTfileID);
            
        end
    
    
    else % Use default hardcoded GT headers and order
    
        warning('%s does not contain column headers!! Assuming default headers.', SGTfile);
    
        while ~isequal(line, -1)
        %for row = 1:length(cellArray{1})
            
            row = row + 1;
            cellArray = strsplit(line, ',', 'CollapseDelimiters', 0);
            
            GT(row).PictureName         =         cellArray{1};   %s
            GT(row).PJImage             =         cellArray{2};   %s
            GT(row).Index               = str2num(cellArray{3}); %d
            GT(row).CameraID            =         cellArray{4};   %s
            GT(row).GT_X                = str2num(cellArray{5}); %d
            GT(row).GT_Y                = str2num(cellArray{6}); %d
            GT(row).GT_Z                = str2num(cellArray{7}); %d
            GT(row).GT_Phi              = str2num(cellArray{8}); %d
            GT(row).GT_Theta            = str2num(cellArray{9}); %d
            GT(row).FingerPresent       = str2num(cellArray{10}); %d
            GT(row).AmbientLightType    =         cellArray{11};   %s
            GT(row).AmbientLightLUX     = str2num(cellArray{12}); %d
            GT(row).PJResolution        =         cellArray{13};   %s
            GT(row).ProjectionSizeInch  = str2num(cellArray{14}); %d
            GT(row).TesterName          =         cellArray{15};   %s
            GT(row).TesterGender        =         cellArray{16};   %s
            GT(row).SkinColour          =         cellArray{17};   %s
            GT(row).FingerSize          =         cellArray{18};   %s
            GT(row).NailColour          =         cellArray{19};   %s
            GT(row).Memo                =         cellArray{20};   %s
                      
            line = fgetl(SGTfileID);
        end
        
    end

    fclose(SGTfileID)