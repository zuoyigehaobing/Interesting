function writeDetResCSV(eval_folder, ALL_detModPoses, GT)

    % INPUTS:
    % (1) eval_folder: (location to save detection results to)
    % (2) ALL_detModPoses: structure array containing module-based detection pose output:
    %     length(ALL_detModPoses) = # of img pairs processed
    %     ALL_detModPoses(i).PictureName = imgname_c1
    %                       .t_detect = detection time
    %                       .detModPoses = structure array, containing raw detection output:
    %                            length(detModPoses) = # of detection submodules
    %                           .detModPoses(i).modName = submodule name
    %                           .detModPoses(i).PoseX/Y/Z = poses returned by that submodule
    % (3) GT: structure array containing GT info for dataset

    % ACTIONS:
    % - saves ALL_detModPoses as a .mat file
    % - for each detection submodule: writes a SEPARATE .csv file containing detection
    %   results (as-is; with no analysis / evaluation done)

    
    
    det_res_folder = fullfile(eval_folder, 'detectionResults');
    mkdir(det_res_folder);
    save(fullfile(det_res_folder, 'detectionResults.mat'), 'ALL_detModPoses', '-mat');
    
    
    for detModIdx = 1:length(ALL_detModPoses(1).detModPoses)
        
        modName = ALL_detModPoses(1).detModPoses(detModIdx).modName;
        fileID = fopen(fullfile(det_res_folder, ['detectionResults_' modName '.csv']), 'w');
        

        % --------------------------------------------------------------------------
        % Write File Headers
        % --------------------------------------------------------------------------
            
        fprintf(fileID, [            ...
            'PictureName'            ...
            ',PoseX  (Matlab frame)' ...
            ',PoseY  (Matlab frame)' ...
            ',PoseTouch (Matlab frame)'                 ...
            ',DetectionTime(allModules)' ] );
            
        % SGT file headers    
        GT_fieldnames = fieldnames(GT);
        for i = 1:length(GT_fieldnames)
            if  strcmp(GT_fieldnames{i}, 'PictureName') || ...
                ~isempty(strfind(GT_fieldnames{i}, 'GT_'))
                % (PictureName and GT_* are written differently)
                continue
            end
            fprintf(fileID, ',%s', GT_fieldnames{i});
        end
        
        % GT_* headers
        fprintf( fileID, [               ...
            ',GT_X (Matlab frame)'       ...
            ',GT_Y (Matlab frame)'       ...
            ',GT_Z '                     ...
            ',GT_Phi'                    ...
            ',GT_Theta'                  ...
            ',GT_Touch'                  ...
            ',GT_X_C1'                   ...
            ',GT_Y_C1'                   ...
            ',GT_X_C2'                   ...
            ',GT_Y_C2'                   ...
            '\n'               ]   );

            
        % --------------------------------------------------------------------------
        % Write File Fields (PoseX/Y/Z, detection time, and GT)
        % --------------------------------------------------------------------------
        
        for imgIdx = 1:length(ALL_detModPoses)
            
            detModPoses = ALL_detModPoses(imgIdx).detModPoses;
            PictureName = ALL_detModPoses(imgIdx).PictureName;
            t_detect    = ALL_detModPoses(imgIdx).t_detect;
            GT_img = GT( findImgIdx(GT, PictureName) );
            
            fprintf(fileID, strrep(PictureName, '\', '/') );
            
            
            for poseIdx = 1:max(1, length(detModPoses(detModIdx).PoseX))
                
                if ~isempty(detModPoses(detModIdx).PoseX)
                    fprintf(fileID, ",%f", detModPoses(detModIdx).PoseX(poseIdx)      );
                    fprintf(fileID, ",%f", detModPoses(detModIdx).PoseY(poseIdx)      );
                    fprintf(fileID, ",%f", detModPoses(detModIdx).PoseTouch(poseIdx)      );
                else
                    fprintf(fileID, ",,,");
                end
                
                % Write SGT/timing info (only on first line) ...
                if poseIdx == 1

                    fprintf(fileID, ", %f", t_detect);
                    
                    % ... and do so automatically for all GT fields ...
                    GT_fieldnames = fieldnames(GT_img);
                    for i = 1:length(GT_fieldnames)
                        if  strcmp(GT_fieldnames{i}, 'PictureName') || ...
                            ~isempty(strfind(GT_fieldnames{i}, 'GT_'))
                            % (... except PictureName and GT_*; these are written differently)
                            continue
                        end
                        
                        GT_field = eval(['GT_img.', GT_fieldnames{i}]);
                        switch class(GT_field)
                            case {'string', 'char'}
                                fprintf(fileID, ", %s", GT_field);
                            case {'uint8', 'uint16', 'uint32', 'etc'}
                                fprintf(fileID, ", %d", GT_field);
                            case {'float', 'double', 'etc'}
                                fprintf(fileID, ", %f", GT_field);
                        end
                    end
                    
                    % Write GT pose info (X/Y/Z/Angle)
                    % If multiple poses, write from left-to-right (not top-down)
                    for i = 1:length(GT_img.GT_X) 
                        fprintf(fileID, ",%f", GT_img.GT_X(i)      );
                        fprintf(fileID, ",%f", GT_img.GT_Y(i)      );
                        fprintf(fileID, ",%f", GT_img.GT_Z(i)      );
                        try 
                            fprintf(fileID, ",%f", GT_img.GT_Phi(i)  );
                            fprintf(fileID, ",%f", GT_img.GT_Theta(i));
                            
                        catch
                            fprintf(fileID, ",,");
                        end
                        
                        % shan
                        fprintf(fileID, ",%f", GT_img.GT_Touch(i));
                            
                    end
                
                end
                
                fprintf(fileID, "\n");
                
            end

        end
        
        fclose(fileID);

    end
        
end

