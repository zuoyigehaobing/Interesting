function [nCorrectPose, nMisclassifiedPose, nFalsePose, ...
          nCorrectGT,   nMisclassifiedGT,   nMissedGT] = ...
    getSubgridStats(detModRes_i, ALL_GT, MinX, MaxX, MinY, MaxY);
    
    PoseX = detModRes_i.PoseX;
    PoseY = detModRes_i.PoseY;
    PoseLabels = detModRes_i.PoseLabels;
    
    GT_labels = detModRes_i.GT_labels;
    GT_X = ALL_GT.GT_X;
    GT_Y = ALL_GT.GT_Y;
    
    PoseIndices = [];
    for i = 1:length(PoseX)
        if PoseX(i) >= MinX && PoseX(i) < MaxX && ...
           PoseY(i) >= MinY && PoseY(i) < MaxY,
            PoseIndices(end+1) = i;
        end
    end
    
    PoseX = PoseX(PoseIndices);
    PoseY = PoseY(PoseIndices);
    PoseLabels = PoseLabels(PoseIndices);
    
    GT_indices = [];
    for i = 1:length(GT_X)
        if GT_X(i) >= MinX && GT_X(i) < MaxX && ...
           GT_Y(i) >= MinY && GT_Y(i) < MaxY,
            GT_indices(end+1) = i;
        end
    end
    
    GT_X = GT_X(GT_indices);
    GT_Y = GT_Y(GT_indices);
    GT_labels = GT_labels(GT_indices);

    
    nCorrectPose       = sum(strcmp(PoseLabels, 'Correct detection'));
    nMisclassifiedPose = sum(strcmp(PoseLabels, 'Misclassified detection'));
    nFalsePose         = sum(strcmp(PoseLabels, 'False detection'));
    nCorrectGT         = sum(strcmp(GT_labels, 'Correctly detected'));
    nMisclassifiedGT   = sum(strcmp(GT_labels, 'Misclassified'));
    nMissedGT          = sum(strcmp(GT_labels, 'Missed'));
    
end