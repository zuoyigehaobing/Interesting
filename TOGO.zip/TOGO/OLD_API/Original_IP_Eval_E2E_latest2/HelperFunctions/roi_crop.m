function roi_crop(ROI_results, forceCrop, targetFolder, filter_relpath, ROI_SIZE)
    %{
        Action Performed
        1) Upon initialization: Keras model is loaded
        2) On each call: input ROI result and do crop based on this
        3) Crop information are saved into matlab variable
        4) Cropped roi images are saved
    %}
    
    % If not forceCrop and ROI_SIZE are same, do nothing
    if ROI_results.ROI_SIZE == ROI_SIZE && ~forceCrop
        return
    end
    ROI_results.ROI_SIZE = ROI_SIZE;
    
    %% GET NECESSARY INFOS AND LOOP OVER IMAGES
    dataset_path = ROI_results.dataset_path;
    target_path = strrep(dataset_path, '\Data\', targetFolder);

    for i = 1:size(ROI_results.images,2)

        % Display Loop progress
        % if ismember(i, round(linspace(1,size(ROI_results.images,2),30)) ), fprintf('%d..', i); end

        % access only, should not modify since useless
        all_poses = ROI_results.images{i}.Poses;
        imgc1_name = ROI_results.images{i}.PictureName;
        imgc2_name = strrep(imgc1_name,'_c1','_c2');

        img_c1 = im2uint8( imread(fullfile(dataset_path, imgc1_name)));
        img_c2 = im2uint8( imread(fullfile(dataset_path, imgc2_name)));

        %% LOOP OVER ALL POSES
        for j = 1:size(all_poses,2)
            % access only, should not modify since useless
            pose = all_poses{j};

            if strcmp(pose.pose_label{1},'No pose found')
                continue;
            end

            % get minimum range of valid ---------- NNED TO CONFIRM
            xmin = round( min( max(pose.posex - ROI_SIZE/2, 1), 1280 - ROI_SIZE ) );
            ymin = round( min( max(pose.posey - ROI_SIZE/2, 1), 800 - ROI_SIZE ) );

            % get the roi region
            roi_c1 = img_c1(ymin:ymin+ROI_SIZE-1, xmin:xmin+ROI_SIZE-1, :);
            roi_c2 = img_c2(ymin:ymin+ROI_SIZE-1, xmin:xmin+ROI_SIZE-1, :);

            % save stuff
            roi_c1_name = strrep(imgc1_name, '.png', ['_roi_' num2str(j) '.png']);
            roi_c2_name = strrep(roi_c1_name, '_c1','_c2');

            make_path = target_path;

            [otherfolders,~,~] = fileparts(roi_c1_name);
            if size(otherfolders,2) > 0
                make_path = fullfile(make_path,otherfolders);
            end

            if exist(make_path, 'dir') == 0
               mkdir(make_path); 
            end

            imwrite(roi_c1, fullfile(target_path,roi_c1_name) );
            imwrite(roi_c2, fullfile(target_path,roi_c2_name) );

            % add the crop information into the ROI_result variable
            ROI_results.images{i}.Poses{j}.ROI_name = roi_c1_name;
            ROI_results.images{i}.Poses{j}.ROI_path = fullfile(target_path,roi_c1_name);
            ROI_results.images{i}.Poses{j}.xmin = xmin;
            ROI_results.images{i}.Poses{j}.ymin = ymin;

        end
    end


    %% Save the updated ROI_results
    [~,filtername,~] = fileparts(filter_relpath);
    save(fullfile(target_path,[filtername '_ROI_results.mat']),'ROI_results', '-mat');

    

end