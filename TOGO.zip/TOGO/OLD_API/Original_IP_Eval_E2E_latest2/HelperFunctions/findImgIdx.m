function idx = findImgIdx(GT, imgName)
    % Find the index corresponding to imgName in GT structure
    for i = 1:length(GT)
        if isequal(GT(i).PictureName, imgName)
            idx = i;
            return
        end 
    end
    idx = -1;
end