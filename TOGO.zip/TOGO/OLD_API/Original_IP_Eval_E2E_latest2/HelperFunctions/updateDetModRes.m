function ALL_detModRes = updateDetModRes(ALL_detModRes, detModRes)

    % Update the variable ALL_detModRes, which contains info for all img pairs of a dataset,
    % with info for the current image pair (from detModRes)
    
    % ALL_detModRes's structure:
	% two fields: .totals and .imgStats
	% .totals is a struct: n_fields = no. of det modules
	% .totals(i).modName, CDR_errs, nPose, nGT, etc. Metrics used for eval summary
	% .imgStats contains one field: detModRes, which is saved as-is (from input argument)
    
    if isempty(fieldnames(ALL_detModRes))
        
        for detModIdx = 1:length(detModRes)
            ALL_detModRes.totals(detModIdx).modName  = detModRes(detModIdx).modName;
            ALL_detModRes.totals(detModIdx).CDR_errs = [];
            ALL_detModRes.totals(detModIdx).nPose    = 0;
            ALL_detModRes.totals(detModIdx).nGT      = 0;
            ALL_detModRes.totals(detModIdx).nCorrect = 0;
            ALL_detModRes.totals(detModIdx).nFalse   = 0;
            ALL_detModRes.totals(detModIdx).nMissed  = 0;
            ALL_detModRes.totals(detModIdx).nMisclassified = 0;
            
            ALL_detModRes.totals(detModIdx).PoseX = [];
            ALL_detModRes.totals(detModIdx).PoseY = [];
            ALL_detModRes.totals(detModIdx).PoseTouch = [];
            ALL_detModRes.totals(detModIdx).PoseLabels = [];
            
            ALL_detModRes.totals(detModIdx).GT_labels = [];
            
        
        end
        
        ALL_detModRes.imgStats = struct;
            
    end
        
    for detModIdx = 1:length(detModRes)
        
        ALL_detModRes.totals(detModIdx).CDR_errs   =[ALL_detModRes.totals(detModIdx).CDR_errs(:);   detModRes(detModIdx).CDR_errs];
        ALL_detModRes.totals(detModIdx).nPose      = ALL_detModRes.totals(detModIdx).nPose         + detModRes(detModIdx).nPose   ;
        ALL_detModRes.totals(detModIdx).nGT        = ALL_detModRes.totals(detModIdx).nGT           + detModRes(detModIdx).nGT     ;
        ALL_detModRes.totals(detModIdx).nCorrect   = ALL_detModRes.totals(detModIdx).nCorrect      + detModRes(detModIdx).nCorrect;
        ALL_detModRes.totals(detModIdx).nFalse     = ALL_detModRes.totals(detModIdx).nFalse        + detModRes(detModIdx).nFalse  ;
        ALL_detModRes.totals(detModIdx).nMissed    = ALL_detModRes.totals(detModIdx).nMissed       + detModRes(detModIdx).nMissed ;
        ALL_detModRes.totals(detModIdx).nMisclassified = ALL_detModRes.totals(detModIdx).nMisclassified + detModRes(detModIdx).nMisclassified;
        
        ALL_detModRes.totals(detModIdx).PoseX      = [ALL_detModRes.totals(detModIdx).PoseX;      detModRes(detModIdx).PoseX     ];
        ALL_detModRes.totals(detModIdx).PoseY      = [ALL_detModRes.totals(detModIdx).PoseY;      detModRes(detModIdx).PoseY     ];
        ALL_detModRes.totals(detModIdx).PoseTouch      = [ALL_detModRes.totals(detModIdx).PoseTouch;      detModRes(detModIdx).PoseTouch     ];
        ALL_detModRes.totals(detModIdx).PoseLabels = [ALL_detModRes.totals(detModIdx).PoseLabels; detModRes(detModIdx).PoseLabels];
        
        ALL_detModRes.totals(detModIdx).GT_labels  = [ALL_detModRes.totals(detModIdx).GT_labels;  detModRes(detModIdx).GT_labels ];
        
    end
        
    if isempty(fieldnames(ALL_detModRes.imgStats)) 
        ALL_detModRes.imgStats.detModRes        = detModRes;
    else                                           
        ALL_detModRes.imgStats(end+1).detModRes = detModRes;
    end
    
end
        
    