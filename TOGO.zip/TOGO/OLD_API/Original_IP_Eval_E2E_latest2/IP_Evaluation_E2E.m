function IP_Evaluation_E2E(IP_Eval_Parameter_Multidataset)

    %{
    MAIN FILE FOR E2E Evaluation
    Can be used as function (one argument: parameter.txt file) 
    or run as a script (user selects parameter file when prompted)
    
    1) Make a bunfle of the Models: Could be ROI; ROI+DL(R); ROI + DL(C); ROI + DL(R) + DL(C) 
    2) Same as before:
        % Filter images / parse playlist of images
        % Parse SGT file to find GT information
        % For each raw image:
        % - Run detection, get estimated pose
        % - Compare to GT, store results
        % Save {results, GT-overlaid images} to output folder, along with source code
    %}

clear all;
s = clock;

%% STEP1: PARSE CONFIG FILE AND LOAD EVALUATION PARAMETERS
if ~exist('IP_Eval_Parameter_Multidataset', 'var')
    [file_, path_] = uigetfile('', 'Select Multi-dataset parameter.m file', '*.m');
    if ~exist('file_', 'var'), return, end
    IP_Eval_Parameter_Multidataset = fullfile(path_, file_);
end

% Read IP_Eval_parameter.txt configuration file and load helper functions
addpath('HelperFunctions');
config = callfunc(IP_Eval_Parameter_Multidataset);


%% STEP2: LOOP OVER ALL DATASETS
for evalIdx = 1:length(config.datasets)
    
    % Load SGT and images
    dataset_path   = config.datasets(evalIdx).dataset_path;
    GT = readSGT(dataset_path);
    
    % Load result folder details and create timestamped folder
    eval_folder = config.datasets(evalIdx).eval_folder;
    [root, folder, ~] = fileparts(eval_folder);
    eval_folder = fullfile(root, [datestr(now(), 'yyyymmdd_HHMMSS'), '_', folder]);
    mkdir(eval_folder); 
    eval_imgs_folder = fullfile(eval_folder, 'imgs'); mkdir(eval_imgs_folder);
    eval_src_folder  = fullfile(eval_folder, 'src');  mkdir(eval_src_folder);
    
    % load eval notes and flags
    eval_desc  = config.datasets(evalIdx).eval_desc;
    iSaveImgs  = config.common.iSaveImgs;
    iProfile   = config.common.iProfile;
    
    % Load detection module
    detect_module      = config.common.detection_module;
    
    % Load correct detection pixel thresholds
    dTouch = config.common.dTouch;
    dR = config.common.dR;
    MinimumHoverZ = config.common.MinimumHoverZ;
    classification_thresh = config.common.classification_thresh;
    ROI_SIZE = config.common.ROI_SIZE;
    
    % Load playlist images or create playlist from filter file; copy to src folder
    filter_file = config.datasets(evalIdx).filter_file; 
    copyfile(filter_file, eval_src_folder);
    pl_file = writePlaylist(dataset_path, filter_file, eval_src_folder);
    [imgNames] = readPlaylist(pl_file);
    
    
    % Save eval code, param/config files & detection module into source folder
    [detect_mod_path, ~, ~] = fileparts(detect_module);
    [~, foldername, ~] = fileparts(detect_mod_path);
    fprintf('%s\n%s', detect_mod_path, fullfile(eval_src_folder, foldername));
    try copyfile(detect_mod_path,  fullfile(eval_src_folder, foldername));
	catch, try copyfile(detect_mod_path, fullfile(fileparts(eval_folder), 'src', foldername));
	catch, try copyfile(detect_mod_path, fullfile(fileparts(eval_folder), 'src'));
	catch, warning('Unable to copy detection module src code from %s', detect_mod_path');
	end, end, end
    % copyfile(IP_Eval_Param,             eval_src_folder);
    copyfile('*.m',                     eval_src_folder);
    copyfile('HelperFunctions', fullfile(eval_src_folder, 'HelperFunctions'));
    
    % Results file header text
    resFileHeaderText = {eval_desc, ['Dataset,',dataset_path],['Detection module,',detect_module], ['ROI Result Folder,' config.roi_eval_root]};
    
    
    
    % Initialize vars used to calculate evaluation metrics
    ALL_GT = struct('GT_X',[],'GT_Y',[],'GT_Touch',[]);
    clear ALL_detModPoses;
    nImgPairs = 0;
    if iProfile, profile clear; end
    fprintf('Total images: [%d]. Imgs processed:\n', length(imgNames));
    
    %% STEP3: DO CROP
    if ~exist(config.datasets(evalIdx).roi_results, 'file') || config.common.forceCrop
        config.common.forceCrop = 1;
        % redirect to the ROI Evaluation Result Folder
        roi_eval_dir = config.datasets(evalIdx).roi_eval_dir;
        % go inside this folder and use loading function to read
        ROI_results_raw = load_ROI_detection(roi_eval_dir,30,config.datasets(evalIdx).dataset_path, config.datasets(evalIdx).dataset_name);
        crop_dataset(ROI_results_raw, config.common.forceCrop, config.common.crop_targetfolder, config.datasets(evalIdx).filter_file, config.common.ROI_SIZE);
    end
    
    %% STEP4: LOAD THE CROP_IMAGES AND CROP_INFORMATIONS
    ROI_results = load(config.datasets(evalIdx).roi_results); 
    ROI_results = ROI_results.ROI_results;
    
    % Run classification for the dataset
    tic;
    if iProfile, profile resume; end
    
    z_string = dataset_based_eval(ROI_results, config.common.detection_module, config.common.classification_thresh, config.python_path);
    
    if iProfile, profile off; end
    t_detect = toc; t_detect = t_detect / size(ROI_results.images,2);
    
    %% STEP5: LOOP OVER ALL IMAGES
    counter = 1;
    for i = 1:size(ROI_results.images,2)
        
        % Display Loop progress
        if ismember(i, round(linspace(1,length(imgNames),30)) ), fprintf('%d..', i); end
        
        imgname_c1 = ROI_results.images{i}.PictureName;
        imgname_c2 = strrep(imgname_c1, '_c1', '_c2');
        
        %%% For Hover Cases Ground Truth
        GT_idx1 = findImgIdx(GT, imgname_c1);
        GT_idx2 = findImgIdx(GT, imgname_c2);
        
        % 20181213 Shan Added
        GT(GT_idx1).GT_X_C1 = 1280 - GT(GT_idx1).GT_X;
        GT(GT_idx1).GT_Y_C1 = 800 - GT(GT_idx1).GT_Y;
        GT(GT_idx1).GT_X_C2 = 1280 - GT(GT_idx2).GT_X;
        GT(GT_idx1).GT_Y_C2 = 800 - GT(GT_idx2).GT_Y;
        
        GT(GT_idx1).GT_X = 1280 - (GT(GT_idx1).GT_X + GT(GT_idx2).GT_X) /2; % Convert from Edge to (MATLAB ignoring ext border)
        GT(GT_idx1).GT_Y = 800 - (GT(GT_idx1).GT_Y + GT(GT_idx2).GT_Y) /2;
        % GT(GT_idx1).GT_X = 1280 - (GT(GT_idx2).GT_X + GT(GT_idx2).GT_X) /2; % Convert from Edge to (MATLAB ignoring ext border)
        % GT(GT_idx1).GT_Y = 800 - (GT(GT_idx2).GT_Y + GT(GT_idx2).GT_Y) /2;
        GT(GT_idx1).GT_Touch = (GT(GT_idx1).GT_Z < config.common.MinimumHoverZ) * 1;
        
        
        
        % [~, modName, ~] = fileparts(config.common.detection_module);
        [detModPoses, counter] = get_classification(ROI_results ,i, counter, z_string, config.common.basedesc);
        
        nImgPairs = nImgPairs + 1;
        
        % Record GT poses for all images that have been processed so far
        ALL_GT.GT_X   = [ALL_GT.GT_X; GT(GT_idx1).GT_X(:)];
        ALL_GT.GT_Y   = [ALL_GT.GT_Y; GT(GT_idx1).GT_Y(:)];
        ALL_GT.GT_Touch   = [ALL_GT.GT_Touch; GT(GT_idx1).GT_Touch(:)];
        
        % Save detection results so far in a MAT variable
        ALL_detModPoses(nImgPairs).PictureName = imgname_c1;
        ALL_detModPoses(nImgPairs).detModPoses = detModPoses;
        ALL_detModPoses(nImgPairs).t_detect    = t_detect;
        
        
    end
        
    %% Detection results summary and analysis
    
    % Save profile/timing info
    if iProfile; profsave(profile('info'), fullfile(eval_folder,'profile')); end

    % Save detection results (raw; without analysis)
    writeDetResCSV(eval_folder, ALL_detModPoses, GT);
    
    % For each dR threshold, analyze and save detection/evaluation results
    for i = length(dR):-1:1
        resFileName = fullfile(eval_folder, ['evalResults_dR=', num2str(dR(i)) '.csv']);
        ALL_detModRes = evaluateDetectionResults(resFileName, dR(i), dTouch, MinimumHoverZ, classification_thresh, ROI_SIZE, ALL_detModPoses, GT, resFileHeaderText, ...
                                                iSaveImgs&&i==1, dataset_path, eval_imgs_folder);
    end

    % Create summary images for all detection modules, using dR(1)
    for detModIdx = 1:length(ALL_detModRes.totals)
        summaryImgName = fullfile(eval_folder, ['summary_img_dR=' num2str(dR(1)) '_' ALL_detModRes.totals(detModIdx).modName '.png']); 
        createSummaryImages(ALL_detModRes.totals(detModIdx), ALL_GT, dR(1), summaryImgName); 
    end   
    
    
    
    
    
end

fprintf("\n");
fprintf("The Time When Evaluation Starts: %d-%d-%d, %d:%d:%d\n", s(1),s(2),s(3),s(4),s(5),round(s(6)));
s = clock;
fprintf("The Time When Evaluation Ends: %d-%d-%d, %d:%d:%d\n", s(1),s(2),s(3),s(4),s(5),round(s(6)));


end
