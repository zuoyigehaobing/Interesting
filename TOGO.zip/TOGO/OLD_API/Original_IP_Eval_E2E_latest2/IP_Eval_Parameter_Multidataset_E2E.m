function config = IP_Eval_Parameter_Multidataset_E2E()
    
    % Returns a MATLAB structure containing evaluation parameters for MULTIPLE datasets
    % with ONE detection module.
    
    % Output: 
    config = struct; ... which contains two fields: .common and .datasets:
    
    % --- config.common ---
    % structure with common-to-all-evals info;
    % parameters that are NOT specific per dataset
    
    % --- config.datasets ---
    % structure ARRAY containing eval-specific info for each dataset
    % length(config.datasets) = # of datasets to evaluate
    % contains fields such as dataset_name/location
    
    % classification Module
    config.common.detection_module = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\DetectionModules\DLClassificationModels\20190221_175143\20190221_175143_TF_classification-25-2.577.hdf5'; 
    % config.common.detection_module = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\DetectionModules\DLClassificationModels\20190311_134926\20190311_134926_TF_classification-25-2.558.hdf5';
    config.common.iSaveImgs = 0;
    config.common.iProfile  = 0; % full detection module timing profile, in addition to tic/toc as reported in results file.
    
    
    config.common.eval_basefolder = 'C:\Users\Public\IPR\JasonWork\Results\Training_ROI+Classi';
    eval_basedesc = 'Training_ROI+Classi';
    config.common.basedesc = eval_basedesc;
    
    config.common.dTouch = 0.01;  % for touch-hover classification, please do not change this
    config.common.dR = [10, 20, 30];
    config.common.MinimumHoverZ = 10; % when z>
    config.common.classification_thresh = 0.5; % Ask Dong or Rui first -> When they this a case to be hover or touching?
    
    
    % Crop Configuration
    % config.common.crop_targetfolder = '\ROI_Cropped_Data\JunRelease004ROI\'; % will replace \Data\
    config.common.crop_targetfolder = '\ROI_Cropped_Data\GT_Feed_X2Y2\'; % will replace \Data\
    config.common.forceCrop = 1;
    config.common.ROI_SIZE = 128;
    
    % This is the root folder where you load the ROI detection result
    % config.roi_eval_root = 'C:\Users\Public\IPR\AntonWork\IP_Evaluation\test_results\20180828_release_V0.0.4_code_freeze_tag_rev965_Copy';
    % config.roi_eval_root = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\test_results\DL_Required_ROI_Evaluation\Official_CYCLE1_Combined_ROI_Eval';
    % config.roi_eval_root = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\test_results\Seq_Required_E2E_Evaluation\ROI_results';
    % config.roi_eval_root = 'C:\Users\Public\IPR\Stuff_Shan\IP_Evaluation\test_results\DL_Required_ROI_Evaluation\ITERATION2_ROI_RESULTS';
    config.roi_eval_root = 'C:\Users\Public\IPR\JasonWork\Results\Training_ROI';
    
    % This is where you load Python
    config.python_path = 'C:\Users\ecl22309\AppData\Local\conda\conda\envs\eval\python.exe';
    
    %% Parameters that ARE specific per dataset
    dataset_names = {... short list of all datasets to evaluate. Comment out datasets that are not to be evaluated
                    ...'323_3DObjectOnScreen_extended',...
                    ...'323_3DObjectOnScreen_false',...
                    ...##### 6 Original Eval datasets (including 4 touching sets, 1 hover set, 2 false sets)
                    ...'SEC9_0mm',...
                    ...'SEC9_5-10mm',...
                    ...'EdgeTouch',...
                    ...'DS1_bndry',...
                    ...'EdgeWalking',...
                    ...'Touch2',...
                    ...'NonPoint',...
                    ...##### Various FromVP eval datasets
                    ...'basicConditionEval',...
                    ...'AmbientLight',...
                    ...%'ReflectionByWatch_Otani_NonTouching',... Don't usually include these
                    ...%'ReflectionByWatch_Otani_touching',...
                    ...'4WCondition',...
                    ...'Occlusion_Otani',...
                    ...'Objects2D',...
                    ...'Objects3D',...
                    ...'ReflectionByPenTray_1',...
                    ...'ReflectionByPenTray_2',...
                    ...'ReflectionByWatch_Otani',...
                    ...
                    ...'20180508_False',...
                    ...'20180807SusanNormalTouchingSequence'...
					...%'20180517SusanNormalTouchingSequence'
                    ...'20180208Micky5mm'...
                    ...'20180208Micky15mm'...
                    ...'20180208MickyTouch'...
                    ...'20180208Rui5mm'...
                    ...'20180208Rui15mm'...
                    ...'20180208RuiTouch'...
                    ...'20180208Susan5mm'...
                    ...'20180208Susan15mm'...
                    ...'20180208SusanTouch'...
                    ...'20180817TahirData'...
                    ...
                    ...'212_BendedFinger',...
                    ...'214_OutOfPlaneAngle',...
                    ...'215_WristAngle',...    
                    ...'303_SpecularReflection',...
                    ...'304_NotSmoothAnbientLight',...
                    ...'311_ReflectionByPentray',...
                    ...'321_WritingOnScreen',...
                    ...'322_2DObjectOnScreen',...
                    ...'FalseOnShadow',...
                    ...'Additional_generated'...
					...'MAYA_Condition'...
                    ...'EvaluationDatasetFromVP2_oike'...
                    ...'CSE_20181010_Rui_Data_mixed'...
                    ...'CSE_20181011_Rui_Data_mixed'...
                    ...'CSE_20181012_Rui_Data_mixed'...
                    ...'CSE_20181017_Rui_Data_mixed'...
                    ...'CSE_20181022_Tahir_Data_mixed'...
                    ...'CSE_20181010_Rui_Data_fp1'...
                    ...'CSE_20181011_Rui_Data_fp1'...
                    ...'CSE_20181012_Rui_Data_fp1'...
                    ...'CSE_20181017_Rui_Data_fp1'...
                    ...'CSE_20181022_Tahir_Data_fp1'...
                    ...'TRAINING_4_CORNORS'...
                    ...'CYCLE1_OFFICIAL'...
                    ...'C2_left_5Regions'...
                    ...'C2_5Regions'...
                    ...'SeqDebugData1'...
                    ...'SeqDebugData2'...
                    ...'C2_ShadowInvestigation'...
                    ...'Dong_White_Board_Investigation'...
                    ...
                    ... % DL Training Data - Jason 20190315 Added
                    'Edge_Cycle2_Touch_left'...
                    'Edge_Cycle2_Touch_right'...
                    'Edge_Cycle2_Hover_left'...
                    'Edge_Cycle2_Hover_right'...
                    ...'Micky_5mm_captool'...
                    ...'Micky_15mm'...
                    ...'Micky_touch'...
                    ...'Rui_5mm_captool'...
                    ...'Rui_15mm'...
                    ...'Rui_touch'...
                    ...'Susan_5mm_captool'...
                    ...'Susan_15mm_captool'...
                    ...'Susan_touch_captool'...
                    ...'Rui_TH_classif0813'...
                    ...'Rui_TH_classif0816'...
                    ...'iteration1_rectified_Dong'...
                    ...'iteration1_rectified_Andrej_Sebastian'...
                    ...'iteration1_rectified_Gary'...
                    ...'iteration1_rectified_Jie'...
                    ...'iteration1_rectified_Jun'...
                    ...'iteration1_rectified_Micky'...
                    ...'iteration1_rectified_Momin'...
                    ...'iteration1_rectified_Rui'...
					...'iteration1_rectified_Shan'...
                    ...'iteration1_rectified_Susan'...
                    ...'iteration1_rectified_Tahir'...
                    ...'TrainC1_4Corners'...
                    ...'TrainC1_Center_8_Regions'...
                    ...'TrainC1_4Borders'...
                    };
                    
    % Define dataset-specific parameters
    for i = 1:length(dataset_names)
        dataset_name = dataset_names{i};
        switch dataset_name
			case 'SEC9_0mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\SEC_images_9\rectify\28dB';
                bkgname_c1       = '0432_10bit-WX-100-W019(IR1W)-000lx-28dB_c1_rectify.png';
                blkname_c1       = '0426_10bit-WX-100-black-000lx_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter0.txt';
                
            case 'SEC9_5-10mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\SEC_images_9\rectify\28dB';
                bkgname_c1       = '0432_10bit-WX-100-W019(IR1W)-000lx-28dB_c1_rectify.png';
                blkname_c1       = '0426_10bit-WX-100-black-000lx_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter5+.txt';
                
            case 'EdgeTouch'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\20180123_touch\Rectified';
                bkgname_c1       = 'img_rgb62_000000_c1_rectify.png';
                blkname_c1       = 'img_black_000000_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
            case 'DS1_bndry'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\Data_set_1_original_1\Data_set_1_rectify_1';
                bkgname_c1       = 'bgs\0951_10bit-WX-100-W035(IR1W)-000lx-28dB-(1270-0790px-000mm-45-00deg)0000_000000_c1_rectify.png';
                blkname_c1       = 'bgs\0623_10bit-WX-100-black-000lx_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter_bound.txt';
                
            case 'EdgeWalking'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\20180116_walking\Rectified';
                bkgname_c1       = 'img_rgb62_000000_c1_rectify.png';
                blkname_c1       = 'img_black_000000_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
            case 'Touch2'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\20180314_Touch\Rectified';
                bkgname_c1       = 'img_rgb62_000000_c1_rectify.png';
                blkname_c1       = 'img_black_000000_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
            case 'NonPoint'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\20180314_NonPoint\Rectified';
                bkgname_c1       = 'video0000_000000_c1_rectify.png';
                blkname_c1       = 'img_black_000000_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
					
			case 'ReflectionByWatch_Otani'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_ReflectionByWatch_Otani\rectified';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
                
            case 'ReflectionByWatch_Otani_NonTouching'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_ReflectionByWatch_Otani\rectified';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_RBW_NonTouching.txt';
                
            case 'ReflectionByWatch_Otani_touching'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_ReflectionByWatch_Otani\rectified';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_RBW_touching.txt';

                
                
			case 'ReflectionByPenTray_1'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_ReflectionByPenTray_Otani\rectified';
                bkgname_c1       = 'missing';
                blkname_c1       = 'missing';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';

			case 'ReflectionByPenTray_2'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_ReflectionByPenTray_Otani_2\rectified';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';

			case 'AmbientLight'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_AmbientLightImage_oike\rectified';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';

			case '4WCondition'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_4WCondition_Otani\rectified';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'basicConditionEval'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\eval_dataset_20180630\rectified\FingerImage';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'missing';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'Occlusion_Otani'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20180630_Occlusion_Otani\rectified';
                bkgname_c1       = 'missing';%'BG_c1_rectify.png';
                blkname_c1       = 'missing';%'img_black_000000_c1_rectify.png';
                filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '20180508_False'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\FalseSets\Screen\20180508';
                bkgname_c1       = 'missing';
                blkname_c1       = 'missing';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case 'Objects2D'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\Objects2D';
                bkgname_c1       = 'missing';
                blkname_c1       = 'missing';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case 'Objects3D'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\EvalData\Objects3D';
                bkgname_c1       = 'missing';
                blkname_c1       = 'missing';
                filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
        
		    case '20180517SusanNormalTouchingSequence'
				dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180517_SusanRealTimSeq\rectified\normalTouching';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
            case '20180807SusanNormalTouchingSequence'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180807_Susan_Touching\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
                
                
                
            case '20180817TahirData'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180817_Tahir_Data\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208Micky5mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Micky\5mm_captool';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208Micky15mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Micky\15mm';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208MickyTouch'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Micky\touch';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
            case '20180208Rui5mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Rui\5mm_captool';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208Rui15mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Rui\15mm';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208RuiTouch'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Rui\touch';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208Susan5mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Susan\5mm_captool';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208Susan15mm'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Susan\15mm_captool';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
            
            case '20180208SusanTouch'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Tahir_Data2\20180208\Rectified\Susan\touch_captool';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_edge.txt';
                
            case '212_BendedFinger'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\212_BendedFinger\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';

            case '214_OutOfPlaneAngle'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\214_OutOfPlaneAngle\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '215_WristAngle'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\215_WristAngle\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';

            case '303_SpecularReflection'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\303_SpecularReflection\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '304_NotSmoothAnbientLight'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\304_NotSmoothAnbientLight\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '311_ReflectionByPentray'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\311_ReflectionByPentray\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '321_WritingOnScreen'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\321_WritingOnScreen\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '322_2DObjectOnScreen'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\322_2DObjectOnScreen\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '323_3DObjectOnScreen_extended'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\323_3DObjectOnScreen\rectified\2.ExtendedCase';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case '323_3DObjectOnScreen_false'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20181230_EvalImages_annotated\323_3DObjectOnScreen\rectified\False';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'FalseOnShadow'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180828_Jun_Additional_Eval\FalseOnShadow\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'Additional_generated'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180828_Jun_Additional_Eval\eval_dataset_20180630\AdditionalImage20180810\rectified';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
			
			case 'MAYA_Condition'
                dataset_path     = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\MicronetConditions';
				bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
		
            case 'EvaluationDatasetFromVP2_oike'
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromVP\20190331_EvaluationDatasetFromVP2_oike\Simulation\Rectify_Edge';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            % 20181109 Shan Added
            case 'CSE_20181010_Rui_Data_mixed' 
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\mixed\20181010_Rui_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'CSE_20181011_Rui_Data_mixed' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\mixed\20181011_Rui_Data';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'CSE_20181012_Rui_Data_mixed' 
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\mixed\20181012_Rui_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'CSE_20181017_Rui_Data_mixed' 
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\mixed\20181017_Rui_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'CSE_20181022_Tahir_Data_mixed'
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\mixed\20181022_Tahir_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            % 20181113 Shan Added
            case 'CSE_20181010_Rui_Data_fp1' 
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\fp_1\20181010_Rui_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'CSE_20181011_Rui_Data_fp1' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\fp_1\20181011_Rui_Data';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'CSE_20181012_Rui_Data_fp1' 
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\fp_1\20181012_Rui_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'CSE_20181017_Rui_Data_fp1' 
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\fp_1\20181017_Rui_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                
            case 'CSE_20181022_Tahir_Data_fp1'
                dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Dataset_CSE_E2E_Eval_Filtered\fp_1\20181022_Tahir_Data';
                bkgname_c1       = 'sgt';
                blkname_c1       = 'sgt';
				filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            % 20181207 Shan Added
            case 'CYCLE1_OFFICIAL' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\Dataset_CSE_E2E_C1_C2\Dataset_CSE_E2E_C1';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            % 20181206 Shan Added
            case 'TRAINING_4_CORNORS' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20181121_Train_C1_4Corners';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            % 20190128 Shan Added
            case 'SeqDebugData1' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Seq_E2E_Debug_Dataset\click_leftbottom_558545310836';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'SeqDebugData2' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Seq_E2E_Debug_Dataset\dragdrop_leftbottom_558888603480';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            % 20190131 Shan Added
            case 'C2_ShadowInvestigation' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\Dataset_CSE_E2E_C2\Init_Shadow_Investigation';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            
            % 201901208 Shan Added
            case 'Dong_White_Board_Investigation' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20190207_Dong_Data\Dong';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            
            % 20190311 Shan Added
            case 'C2_left_5Regions' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\Dataset_CSE_E2E_C1_C2\Dataset_CSE_E2E_C2\CornerData';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'C2_5Regions' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\Dataset_CSE_E2E_C1_C2\Dataset_CSE_E2E_C2';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            % 20190315_Training_Data
            case 'Edge_Cycle2_Touch_left' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20190211_Train_C2_FingerPose_Touch';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Edge_Cycle2_Touch_right' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20190211_Train_C2_FingerPose_Touch';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Edge_Cycle2_Hover_left' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20190221_Train_C2_FingerPose_Hover';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Edge_Cycle2_Hover_right' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20190221_Train_C2_FingerPose_Hover';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Micky_5mm_captool' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Micky\5mm_captool';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Micky_15mm' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Micky\15mm';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Micky_touch' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Micky\touch';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Rui_5mm_captool' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Rui\5mm_captool';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Rui_15mm' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Rui\15mm';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Rui_touch' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Rui\touch';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Susan_5mm_captool' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Susan\5mm_captool';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
                    
            case 'Susan_15mm_captool' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Susan\15mm_captool';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Susan_touch_captool' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\20180208-09_TH_classif\withoutExtBorder\20180208\Rectified\Susan\touch_captool';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Rui_TH_classif0813' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Rui_TH_classif\20180813_Phi30+150_Theta45_watt1_Z0+15';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'Rui_TH_classif0816' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\Rui_TH_classif\20180816_Phi45+135_Theta45_watt1_Z0+15';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Dong' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Dong';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Andrej_Sebastian' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Andrej_Sebastian';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Gary' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Gary';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Jie' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Jie';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Jun' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Jun';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Micky' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Micky';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Momin' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Momin';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Rui' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Rui';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Shan' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Shan';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
           
            case 'iteration1_rectified_Susan' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Susan';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'iteration1_rectified_Tahir' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\iteration1_watt1\rectified_Tahir';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'TrainC1_4Corners' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20181121_Train_C1_4Corners';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'TrainC1_Center_8_Regions' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20181127_Train_C1_Center_8_Regions';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
            
            case 'TrainC1_4Borders' 
            dataset_path = 'C:\Users\Public\IPR\DataServerBkp\Data\FromEdge\DL_Datasets\20181218_Train_C1_4Borders';
            bkgname_c1       = 'sgt';
            blkname_c1       = 'sgt';
            filter_file      = 'ConfigFiles\image_pl_filter_EMPTY.txt';
        end
    
        config.datasets(i).dataset_name     = dataset_name;     
        config.datasets(i).dataset_path     = dataset_path;     
        config.datasets(i).bkgname_c1       = bkgname_c1;       
        config.datasets(i).blkname_c1       = blkname_c1;       
        config.datasets(i).filter_file      = filter_file;
        
        % If you have cropped the image and saved it somewhere
        config.datasets(i).roi_eval_dir = roi_eval_dir_finder(config.roi_eval_root,dataset_name);
        config.datasets(i).roi_results      = crop_results_finder(dataset_path, config.common.crop_targetfolder, filter_file);
        
        config.datasets(i).eval_folder      = fullfile(config.common.eval_basefolder, dataset_names{i});
        config.datasets(i).eval_desc        = [eval_basedesc ' on ' dataset_names{i}];
        
    end
    
    
    
end


%% SHAN HELPER FUNCTION : GIVEN ROI_EVALUATION ROOT FOLDER, AUTOMATICALLY FIND THE FOLDER_PATH AS ROI_EVAL_DIR
function rval = roi_eval_dir_finder(rootpath, dataset_name)
    
% Loop over all folders in the root folder, find the folder path that
% matches the dataset name

folders = dir(rootpath);
found = 0;
rval = '';
for i =3:size(folders,1)
    
    if ~folders(i).isdir
        continue;
    end
    
    folder = folders(i).name;
    if contains(folder,dataset_name)
        if found == 1
            error("Duplicate Evaluation in the root folder.");
        end
        found = 1;
        rval = fullfile(rootpath, folder);
    end
    
end
    

end


function rval = crop_results_finder(dataset_path, target_folder, filter_relpath)
    
    rval = strrep(dataset_path,'\Data\', target_folder);
    [~,filtername,~] = fileparts(filter_relpath);
    rval = fullfile(rval,[filtername '_ROI_results.mat']);
end

