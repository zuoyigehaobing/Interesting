function tmp2 = dataset_based_eval(ROI_results, modelpath, classification_thresh, python_path)

    collection = {};
    for i = 1:size(ROI_results.images,2)
        for j = 1:size(ROI_results.images{i}.Poses,2)
            if size(ROI_results.images{i}.Poses,2) == 1 && strcmp(ROI_results.images{i}.Poses{1}.pose_label{1},'No pose found')
                continue;
            end
            roi_c1_path = ROI_results.images{i}.Poses{j}.ROI_path;
            collection{end+1} = roi_c1_path;
        end
    end
    
    % Save the collection variable and load it into python
    collection_save_name = [datestr(now(), 'yyyymmdd_HHMMSS'), '_', 'collection.mat'];
    save(collection_save_name,'collection', '-mat');
    
    mat_var_path = fullfile(pwd,collection_save_name);
    
    thre = num2str(classification_thresh);
    
    use_python = fullfile(pwd, 'dataset_based_eval.py');
    
    systemCommand1 = python_path;
    systemCommand2 = [' ' use_python];
    systemCommand3 = [' ' modelpath ' ' mat_var_path ' ' thre];
    systemCommand = [systemCommand1 systemCommand2 systemCommand3];
    
    [~, commandOut] = system(systemCommand);
    tmp1 = extractAfter(commandOut , 'tnt');
    tmp2 = extractBefore(tmp1 , 'result');
    
    tmp2
    
    % Remove the collection file
    delete(mat_var_path);
end