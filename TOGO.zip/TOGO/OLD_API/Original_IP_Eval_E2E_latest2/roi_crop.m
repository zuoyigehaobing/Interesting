function roi_crop(IP_Eval_Parameter_Multidataset)

%{
    MAIN FILE FOR IMAGE CROP
    1) Read and organize the detection result from ROI-Evaluation
    2) Crop the image based on the detection
    3) Save the Cropped rois and their informations
    4) Save the variables that contains the crop-history.
%}


%% Step1: PARSE CONFIG FILE AND LOAD EVALUATION PARAMETERS
if ~exist('IP_Eval_Parameter_Multidataset', 'var')
    [file_, path_] = uigetfile('', 'Select Multi-dataset parameter.m file', '*.m');
    if ~exist('file_', 'var'), return, end
    IP_Eval_Parameter_Multidataset = fullfile(path_, file_);
end


% Read IP_Eval_parameter.txt configuration file
config = callfunc(IP_Eval_Parameter_Multidataset);


%% Step2: CROP THE IMAGE AND SAVE THE CORRESPONDING INFORMATIONS
for evalIdx = 1:length(config.datasets)
    
    fprintf("\nWorking on Dataset %s (%d / %d)\n", config.datasets(evalIdx).dataset_name, evalIdx ,size(config.datasets,2));
    % redirect to the ROI Evaluation Result Folder
    roi_eval_dir = config.datasets(evalIdx).roi_eval_dir;
    
    % go inside this folder and use loading function to read
    ROI_results = load_ROI_detection(roi_eval_dir,30,config.datasets(evalIdx).dataset_path, config.datasets(evalIdx).dataset_name);
    
    % do crop
    crop_dataset(ROI_results, config.common.forceCrop, config.common.crop_targetfolder, config.datasets(evalIdx).filter_file, config.common.ROI_SIZE);
    
end



fprintf('\n');
end
