function [detModPoses, counter]=get_classification(ROI_results, idx, counter, z_rval, modName)
    
    detModPoses = struct;
    detModPoses.modName = modName;
    detModPoses.PoseX = [];
    detModPoses.PoseY = [];
    detModPoses.PoseTouch = [];
    
    if size(ROI_results.images{idx}.Poses,2) == 1 && strcmp(ROI_results.images{idx}.Poses{1}.pose_label{1},'No pose found')
         return
    end
    
    
    for j = 1:size(ROI_results.images{idx}.Poses,2)
        
        isTouch = str2double(char(z_rval(counter)));
        counter = counter + 1;
        
        PoseX = ROI_results.images{idx}.Poses{j}.posex;
        PoseY = ROI_results.images{idx}.Poses{j}.posey;
        
        detModPoses.PoseX = [detModPoses.PoseX; PoseX];
        detModPoses.PoseY = [detModPoses.PoseY; PoseY];
        detModPoses.PoseTouch = [detModPoses.PoseTouch; isTouch];
    end
    
    
    
end