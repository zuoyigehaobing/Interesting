import scipy.io
import sys
import argparse
import numpy as np
import keras
import cv2
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('modelFile', type=str)
    parser.add_argument('matlab_variable', type=str)
    parser.add_argument('probThreshold', type=float)
    args = parser.parse_args()

    # Load model
    if args.modelFile:
        model = keras.models.load_model(args.modelFile, compile=False)
    else:
        raise Exception('Model File loading Error')
    
    # Load ROIs
    variable = scipy.io.loadmat(args.matlab_variable)
    collection = variable['collection']


    rval = ''
    # start to loop to find rois
    for i in collection[0]:
        roi_c1_path = i[0]
        roi_c2_path = roi_c1_path.replace('_c1_','_c2_')

        imgL = cv2.imread(roi_c1_path, cv2.IMREAD_GRAYSCALE)
        imgR = cv2.imread(roi_c2_path, cv2.IMREAD_GRAYSCALE)
        left_image_batch = np.zeros((1, 128, 128, 1))
        right_image_batch = np.zeros((1, 128, 128, 1))
        left_image_batch[0, :, :, 0] = imgL
        right_image_batch[0, :, :, 0] = imgR

        # Perform evaluation
        pred_score = model.predict([left_image_batch, right_image_batch])
        pred_class = 1 if pred_score > args.probThreshold else 0

        output_val = str(pred_class)
        rval += output_val
    
    to_print = 'tnt' + rval + 'result'
    sys.stdout.write(to_print)
    
    # sys.stdout.write('tnt')
    # sys.stdout.write(rval)
    # sys.stdout.write('result')